--  ----------------------- PLANTONISTA --------------------------
--                                                                  
--                    SCRIPT VIEW (DDL)                           
--                                                                  
-- Data Criacao ..........: 14/10/2019                              
-- Autor(es) .............: Welison Regis     
-- Banco de Dados ........: MySQL                                   
-- Base de Dados(nome) ...: aula3exer1Evolucao4                                                                                      
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 3 Usuarios                                             
--                                                                  
-- -----------------------------------------------------------------

USE aula3exer1Evolucao4;

-- CRIAÇÃO DE VIEW (voltada ao usuário)

-- Propósito da análise:
-- Visualização dos plantonistas que trabalharão em dado setor em certo horário.
-- 
-- Nessa situação, um índice seria importante para lidar com a cláusula
-- WHERE com timestamp e id, pois, caso haja muitos dados do banco, o index
-- utilizando de uma BTREE irá filtrar as datas e identificadores de uma
-- maneira mais rápida, visto que esses atributos são os mais relevantes
-- da tabela.

CREATE INDEX trabalhaSetor ON trabalha (dataHora, idSetor);

CREATE OR REPLACE VIEW v_PLANTONISTA_DATA AS
SELECT T.matricula, nome, dataHora, ROUND(duracao/60, 1) AS `duracao (h)`, nomeSetor
	FROM trabalha as T USE INDEX (trabalhaSetor)
		INNER JOIN PLANTONISTA AS P
			ON T.matricula = P.matricula
		INNER JOIN SETOR AS S
			ON T.idSetor = S.idSetor
	WHERE T.dataHora >= '2019-05-27 16:00:00' AND T.dataHora <= '2019-05-28 00:00:00' AND T.idSetor = 2
    ORDER BY S.nomeSetor, T.dataHora, P.nome;

SELECT * FROM v_PLANTONISTA_DATA;


-- CRIAÇÃO DE SELECT (voltada ao gestor)

-- Propósito da análise:
-- Mostra a quantidade de plantonistas em dado setor em dado horário.
-- Comparação: Demanda do público ao setor x Funcionários do setor
-- 
-- Preferiu-se não utilizar index, pois se trata de uma consulta mais simples
-- e bem otimizada pelo próprio SGBD.

SELECT nomeSetor, qtPlantonista
 FROM SETOR S
  LEFT JOIN (SELECT idSetor, COUNT(idSetor) AS qtPlantonista
   FROM trabalha
       WHERE dataHora >= '2019-05-27 16:00:00' AND dataHora <= '2019-05-28 00:00:00'
       GROUP by idSetor) AS T
   ON S.idSetor = T.idSetor;
