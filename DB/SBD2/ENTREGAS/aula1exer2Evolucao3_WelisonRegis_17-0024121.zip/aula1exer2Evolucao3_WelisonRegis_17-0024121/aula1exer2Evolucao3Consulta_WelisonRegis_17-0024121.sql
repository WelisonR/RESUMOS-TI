-- --------     << VENDAS >>     ------------
-- 
--                    SCRIPT DE SELECAO (DML)
-- 
-- Data Criacao ...........: 26/08/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula1exer2Evolucao3
-- 
-- Data Ultima Alteracao ..: 26/08/2019
--   => Criacao do script que apaga
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula1exer2Evolucao3;

-- Consultar todas as vendas feitas por um empregado específico definido pela sua chave primária na pesquisa;
SELECT idVenda, dtVenda
FROM VENDA
WHERE matricula = 9090123;

-- Relacionar todos os dados de uma venda com todas as informações dos produtos comercializados por esta venda específica;
SELECT V.idVenda, V.dtVenda, V.matricula, P.nomeProduto, C.codProduto, C.quantidade, C.precoUnitario
FROM VENDA AS V
INNER JOIN contem AS C ON V.idVenda  = C.idVenda
INNER JOIN PRODUTO AS P ON C.codProduto = P.codProduto
WHERE V.idVenda = 1;

-- Mostrar todos os empregados da empresa que não sejam gerentes em ordem alfabética crescente;
SELECT P.cpf, E.matricula, P.nome, P.senha, t.telefone, E.numero, E.logradouro, E.bairro, E.cidade, E.uf, E.cep
FROM PESSOA AS P
INNER JOIN EMPREGADO AS E ON P.cpf = E.cpf
LEFT JOIN telefone t ON t.matricula = E.matricula
ORDER BY P.nome ASC;

-- Consultar e mostrar a quantidade de CADA produto que foi vendido por esta empresa.
SELECT P.codProduto AS `Código`, P.nomeProduto AS `Nome`, SUM(c.quantidade) AS `Quantidade`
FROM PRODUTO P
INNER JOIN contem c ON P.codProduto = c.codProduto
GROUP BY P.codProduto;
