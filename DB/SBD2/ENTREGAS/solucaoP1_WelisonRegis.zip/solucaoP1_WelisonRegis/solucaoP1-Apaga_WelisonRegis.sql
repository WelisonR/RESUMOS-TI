-- --------------     << DISCIPLINAS >>     ---------------------
--
--                    SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: WelisonRegis
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuários
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE WelisonRegis;

DROP TABLE leciona;
DROP TABLE necessita;
DROP TABLE email;
DROP TABLE DISCIPLINA;
DROP TABLE PROFESSOR;
DROP USER 'ADMIN';
DROP USER 'PESSOA';
DROP VIEW v_DISCIPLINA_necessita;