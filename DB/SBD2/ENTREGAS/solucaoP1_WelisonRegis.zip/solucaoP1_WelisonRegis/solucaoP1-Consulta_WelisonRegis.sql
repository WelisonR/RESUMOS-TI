-- --------------     << DISCIPLINAS >>     ---------------------
--
--                    SCRIPT DE CONSULTA (DQL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: WelisonRegis
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuários
--         => 01 Visao
--
-- -----------------------------------------------------------------

-- View retornará as disciplinas e professores daquelas disciplinas que
-- não possuem pré-requisitos.
-- Chave de procura: identificadores únicos (IDs).

-- Índice: Não há necessidade de criar um índice, pois a consulta será
-- performada rapidamente devido as chaves escolhidas pras tabelas.

USE WelisonRegis;

CREATE VIEW v_DISCIPLINA_necessita AS
SELECT D.idDisciplina, D.nome, P.primeiroNome, P.UltimoNome
	FROM DISCIPLINA D
		LEFT JOIN necessita N
			ON D.idDisciplina = N.idDisciplina
    INNER JOIN leciona L
			ON D.idDisciplina = L.idDisciplina
		INNER JOIN PROFESSOR P
			ON L.idProfessor = P.idProfessor
	WHERE N.idDisciplina IS NULL
	ORDER BY D.idDisciplina;

SELECT * FROM v_DISCIPLINA_necessita;