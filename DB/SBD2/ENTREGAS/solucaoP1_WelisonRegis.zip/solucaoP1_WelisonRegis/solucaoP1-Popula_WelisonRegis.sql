-- --------------     << DISCIPLINAS >>     ---------------------
--
--                    SCRIPT DE POPULAR (DML)
--
-- Data Criacao ...........: 21/10/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: WelisonRegis
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuários
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE WelisonRegis;

INSERT INTO PROFESSOR VALUES
	(NULL, 'João', 'Assis', '1995-04-20', 'M'),
  (NULL, 'Maria', 'Mendes', '1997-03-19', 'F'),
  (NULL, 'Gabriela', 'Farias', '1999-05-20', 'F'),
  (NULL, 'Takayiki', 'Noguriki', '1975-12-20', 'M');

INSERT INTO DISCIPLINA VALUES
	(NULL, 'Cálculo 1', 'C1', 6, 'M'),
  (NULL, 'Matemática Discreta 2', 'MD2', 4, 'V'),
  (NULL, 'Introdução a Economia', 'INTECO', 4, 'M'),
  (NULL, 'Engenharia de Segurança', 'ENGSEG', 6, 'V'),
  (NULL, 'Gestão Ambiental', 'GA', 4, 'M');

INSERT INTO email VALUES
	(1, 'joaoassis1@gmail.com'),
  (1, 'joaozinho123@outlook.com'),
  (2, 'mendesmeme@hotmail.com'),
  (3, 'gabifari@gmail.com');

INSERT INTO necessita VALUES
	(2, 1),
  (3, 1),
  (4, 3),
  (5, 4);

INSERT INTO leciona VALUES
	(1, 1),
  (2, 2),
  (3, 3),
  (4, 4);