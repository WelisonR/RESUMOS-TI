--  ----------------------- PLANTONISTA ---------------------------
--                                                                  
--                    SCRIPT DE CRIACAO (DDL)                       
--                                                                  
-- Data Criacao ..........: 30/09/2019                              
-- Autor(es) .............: Welison Regis
-- Banco de Dados ........: MySQL                                   
-- Base de Dados(nome) ...: aula3exer1                   
--                                                                  
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas                                             
--                                                                  
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula3exer1;

USE aula3exer1;

CREATE TABLE PLANTONISTA (
    matricula INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    CONSTRAINT PLANTONISTA_PK PRIMARY KEY (matricula)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE SETOR (
    idSetor INT NOT NULL AUTO_INCREMENT,
    nomeSetor VARCHAR(50) NOT NULL,
    CONSTRAINT SETOR_PK PRIMARY KEY (idSetor)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8 AUTO_INCREMENT = 1;

CREATE TABLE trabalha (
    matricula INT NOT NULL,
	idSetor INT NOT NULL,
    dataHora TIMESTAMP NOT NULL,
    CONSTRAINT trabalha_PK PRIMARY KEY (matricula, dataHora),
    CONSTRAINT trabalha_SETOR_FK FOREIGN KEY (idSetor)
        REFERENCES SETOR (idSetor),
    CONSTRAINT trabalha_PLANTONISTA_FK FOREIGN KEY (matricula)
        REFERENCES PLANTONISTA (matricula)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE ESPECIALIDADE (
    codEspecialidade INT NOT NULL,
    nomeEspecialidade VARCHAR(50) NOT NULL,
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (codEspecialidade)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;

CREATE TABLE tem (
    matricula INT NOT NULL,
    codEspecialidade INT NOT NULL,
    CONSTRAINT tem_PK PRIMARY KEY (matricula, codEspecialidade),
    CONSTRAINT tem_ESPECIALIDADE_FK FOREIGN KEY (codEspecialidade) 
        REFERENCES ESPECIALIDADE (codEspecialidade),
    CONSTRAINT tem_PLANTONISTA_FK FOREIGN KEY (matricula) 
        REFERENCES PLANTONISTA (matricula)
) ENGINE = InnoDB DEFAULT CHARSET = UTF8;
