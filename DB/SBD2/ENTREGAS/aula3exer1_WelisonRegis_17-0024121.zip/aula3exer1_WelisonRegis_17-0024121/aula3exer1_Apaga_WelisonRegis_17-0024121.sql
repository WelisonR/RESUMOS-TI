--  ----------------------- PLANTONISTA ---------------------------
--                                                                  
--                    SCRIPT APAGA (DDL)                            
--                                                                  
-- Data Criacao ..........: 30/09/2019                              
-- Autor(es) .............: Welison Regis      
-- Banco de Dados ........: MySQL                                   
-- Base de Dados(nome) ...: aula3exer1                     
--                                                                  
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas                                             
--                                                                  
-- -----------------------------------------------------------------

USE aula3exer1;

DROP TABLE tem;
DROP TABLE ESPECIALIDADE;
DROP TABLE trabalha;
DROP TABLE SETOR;
DROP TABLE PLANTONISTA;
