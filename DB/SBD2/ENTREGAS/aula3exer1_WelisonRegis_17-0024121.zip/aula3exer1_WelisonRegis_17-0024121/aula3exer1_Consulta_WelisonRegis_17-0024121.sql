--  ----------------------- PLANTONISTA --------------------------
--                                                                  
--                    SCRIPT POPULA (DML)                           
--                                                                  
-- Data Criacao ..........: 29/09/2019                              
-- Autor(es) .............: Welison Regis     
-- Banco de Dados ........: MySQL                                   
-- Base de Dados(nome) ...: aula3exer1                     
--                                                                  
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas                                             
--                                                                  
-- -----------------------------------------------------------------

USE aula3exer1;

-- CRIAÇÃO DE VIEW

-- Crie uma view que possibilite visualizar os plantonistas (matrícula e nome)
-- com os respectivos setores daqueles funcionários que começam a trabalhar
-- em um intervalo horário.

-- Propósito da análise:
-- Plantonista horário real x Plantonista horário de chegada (ponto eletrônico)
-- Plantonistas x Demanda de dado horário para dado setor; 

CREATE OR REPLACE VIEW PLANTONISTA_DATA AS
SELECT T.matricula, nome, dataHora, nomeSetor
	FROM trabalha as T
		INNER JOIN PLANTONISTA AS P
			ON T.matricula = P.matricula
		INNER JOIN SETOR AS S
			ON T.idSetor = S.idSetor
	WHERE T.dataHora > '2019-05-27 16:00:00' AND T.dataHora < '2019-05-28 00:00:00'
    ORDER BY S.nomeSetor, T.dataHora, P.nome;

SELECT * FROM PLANTONISTA_DATA;
