--  ----------------------- PLANTONISTA ---------------------------
-- 								                                         
-- 		                	SCRIPT DE CONTROLE 			                
-- 								                                            
-- Data Criacao ..........: 30/09/2019  			                    
-- Autor(es) .............: Welison Regis	      
-- Banco de Dados ........: MySQL 				                        
-- Base de Dados(nome) ...: aula3exer1 			           
-- 								                           	      
-- 								                                              
-- PROJETO => 01 Base de Dados 					                        
--         => 05 Tabelas 						                            
-- 								                                              
-- --------------------------------------------------------------- 

-- Administrador: possui todos os privilégios sobre essa base de dados somente:

CREATE USER 'levichan1' IDENTIFIED BY 'LeviSenha1@2#';
GRANT ALL PRIVILEGES ON aula3exer1.* TO levichan1;

-- Usuario: possui todos os privilégios de consulta de dados sobre a base de dados desse projeto somente:

CREATE USER 'joaoRocha9' IDENTIFIED BY 'JoaoRR1@2#';
GRANT SELECT ON aula3exer1.* TO joaoRocha9;

-- Gestor: possui os privilégios de consultar os dados de todas as tabelas dessa base de dados, 
-- mas também pode cadastrar e alterar dados do plantonista e do setor do hospital.

CREATE USER 'IvanDoblin1' IDENTIFIED BY 'DjaaPP1@2#';
GRANT SELECT, INSERT, UPDATE ON aula3exer1.* TO IvanDoblin1;
