--  ----------------------- PLANTONISTA ---------------------------
--                                                                  
--                    SCRIPT APAGA (DDL)                            
--                                                                  
-- Data Criacao ..........: 30/09/2019                              
-- Autor(es) .............: Welison Regis      
-- Banco de Dados ........: MySQL                                   
-- Base de Dados(nome) ...: aula3exer1Evolucao2                                                                                  
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 3 Usuarios                                             
--                                                                  
-- -----------------------------------------------------------------

USE aula3exer1Evolucao2;

DROP TABLE tem;
DROP TABLE ESPECIALIDADE;
DROP TABLE trabalha;
DROP TABLE SETOR;
DROP TABLE PLANTONISTA;
