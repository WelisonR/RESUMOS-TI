--  ----------------------- PLANTONISTA ---------------------------
-- 								                                         
-- 		                	SCRIPT DE CONTROLE (DCL) 			                
-- 								                                            
-- Data Criacao ..........: 30/09/2019  			                    
-- Autor(es) .............: Welison Regis	      
-- Banco de Dados ........: MySQL 				                        
-- Base de Dados(nome) ...: aula3exer1Evolucao2 			                                                                            
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 3 Usuarios 						                            
-- 								                                              
-- --------------------------------------------------------------- 

-- Administrador: possui todos os privilégios sobre essa base de dados somente:

CREATE USER 'levichan1' IDENTIFIED BY 'LeviSenha1@2#';
GRANT ALL PRIVILEGES ON aula3exer1Evolucao2.* TO levichan1;

-- Usuario: possui todos os privilégios de consulta de dados sobre a base de dados desse projeto somente:

CREATE USER 'joaoRocha9' IDENTIFIED BY 'JoaoRR1@2#';
GRANT SELECT ON aula3exer1Evolucao2.* TO joaoRocha9;

-- Gestor: possui os privilégios de consultar os dados de todas as tabelas dessa base de dados, 
-- mas também pode cadastrar e alterar dados do plantonista e do setor do hospital.

CREATE USER 'IvanDoblin1' IDENTIFIED BY 'DjaaPP1@2#';
GRANT SELECT, INSERT, UPDATE ON aula3exer1Evolucao2.* TO IvanDoblin1;
