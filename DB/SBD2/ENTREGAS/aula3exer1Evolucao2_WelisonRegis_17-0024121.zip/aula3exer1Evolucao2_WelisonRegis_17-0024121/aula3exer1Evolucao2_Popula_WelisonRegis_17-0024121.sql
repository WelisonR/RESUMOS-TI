--  ----------------------- PLANTONISTA ---------------------------
--                                                                   
--                    SCRIPT POPULA (DML)                            
--                                                                   
-- Data Criacao ..........: 30/09/2019                               
-- Autor(es) .............: Welison Regis
-- Banco de Dados ........: MySQL                                    
-- Base de Dados(nome) ...: aula3exer1Evolucao2                      
--                                                                   
-- Data Ultima Alteracao ..: 02/10/2019
--   => Edição no popula da tabela trabalha                                                                  
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 3 Usuarios                                              
--                                                                   
-- ----------------------------------------------------------------- 

USE aula3exer1Evolucao2;

INSERT PLANTONISTA VALUES
    (12345, 'Jorge Matheus da Silva', 'M'),
    (12346, 'Emanuel Richster Roussef', 'M'),
    (12347, 'Alexandre de Moraes', 'M');

INSERT SETOR VALUES 
    (NULL, 'Emergência'),
    (NULL, 'Ambulatório'),
    (NULL, 'Fisioterapia');

INSERT trabalha VALUES 
    (12345, 1, '2019-05-28 15:00:00', 720),
    (12346, 2, '2019-05-27 19:30:00', 480),
    (12347, 3, '2019-05-27 20:00:00', 480);

INSERT ESPECIALIDADE VALUES
    (1000, 'Cuidados Intensivos'),
    (1001, 'Oncologia'),
    (1002, 'Clínica e Cirúrgica'),
    (1003, 'Nefrologia');

INSERT tem VALUES
    (12345, 1000),
    (12345, 1001),
    (12346, 1002),
    (12347, 1003);
