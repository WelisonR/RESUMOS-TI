--  ----------------------- PLANTONISTA --------------------------
--                                                                  
--                    SCRIPT VIEW (DDL)                           
--                                                                  
-- Data Criacao ..........: 06/10/2019                              
-- Autor(es) .............: Welison Regis     
-- Banco de Dados ........: Oracle                                   
-- Base de Dados(nome) ...: aula3exer1EvolucaoOracle                                                                                      
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 1 Sequencia
--         => 1 Trigger                                             
--                                                                  
-- -----------------------------------------------------------------

-- CRIAÇÃO DE VIEW

-- Crie uma view que possibilite visualizar os plantonistas (matrícula e nome)
-- com os respectivos setores daqueles funcionários que começam a trabalhar
-- em dado intervalo horário.

-- Propósito da análise:
-- Plantonista horário real x Plantonista horário de chegada (ponto eletrônico)
-- Plantonistas x Demanda de dado horário para dado setor; 

CREATE OR REPLACE VIEW WLAR_v_PLANTONISTA_DATA AS
SELECT T.matricula, nome, dataHora, (SELECT ROUND(duracao/60, 1) FROM DUAL) AS duracao, nomeSetor
	FROM WLAR_trabalha T
		INNER JOIN WLAR_PLANTONISTA P
			ON T.matricula = P.matricula
		INNER JOIN WLAR_SETOR S
			ON T.idSetor = S.idSetor
	WHERE T.dataHora >= TIMESTAMP '2019-05-27 16:00:00' AND T.dataHora <= TIMESTAMP '2019-05-28 00:00:00'
    ORDER BY S.nomeSetor, T.dataHora, P.nome;

SELECT * FROM WLAR_v_PLANTONISTA_DATA;
