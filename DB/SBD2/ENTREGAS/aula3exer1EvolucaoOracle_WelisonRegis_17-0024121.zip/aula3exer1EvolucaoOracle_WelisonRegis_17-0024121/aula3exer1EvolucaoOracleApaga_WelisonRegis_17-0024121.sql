--  ----------------------- PLANTONISTA ---------------------------
--                                                                  
--                    SCRIPT APAGA (DDL)                            
--                                                                  
-- Data Criacao ..........: 06/10/2019                              
-- Autor(es) .............: Welison Regis      
-- Banco de Dados ........: Oracle                                   
-- Base de Dados(nome) ...: aula3exer1EvolucaoOracle                                                                                 
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 1 Sequencia
--         => 1 Trigger                                             
--                                                                  
-- -----------------------------------------------------------------

DROP TABLE WLAR_tem;
DROP TABLE WLAR_ESPECIALIDADE;
DROP TABLE WLAR_trabalha;
DROP TABLE WLAR_SETOR;
DROP TABLE WLAR_PLANTONISTA;
DROP SEQUENCE WLAR_SETOR_SQ;
