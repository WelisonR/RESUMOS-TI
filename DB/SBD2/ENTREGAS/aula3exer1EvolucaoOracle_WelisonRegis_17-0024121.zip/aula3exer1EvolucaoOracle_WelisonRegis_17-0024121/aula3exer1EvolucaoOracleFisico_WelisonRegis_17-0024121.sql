--  ----------------------- PLANTONISTA ---------------------------
--                                                                  
--                    SCRIPT DE CRIACAO (DDL)                       
--                                                                  
-- Data Criacao ..........: 06/10/2019                              
-- Autor(es) .............: Welison Regis
-- Banco de Dados ........: Oracle                                  
-- Base de Dados(nome) ...: aula3exer1EvolucaoOracle                   
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 1 Sequencia
--         => 1 Trigger                                             
--                                                                  
-- -----------------------------------------------------------------

CREATE TABLE WLAR_PLANTONISTA (
    matricula NUMBER(8) NOT NULL,
    nome VARCHAR2(50) NOT NULL,
    sexo VARCHAR2(1) NOT NULL,
    CONSTRAINT PLANTONISTA_PK PRIMARY KEY (matricula),
    CONSTRAINT PLANTONISTA_sexo_CK CHECK (sexo IN ('M', 'F'))
);

CREATE TABLE WLAR_SETOR (
    idSetor NUMBER(6) NOT NULL,
    nomeSetor VARCHAR2(50) NOT NULL,
    CONSTRAINT SETOR_PK PRIMARY KEY (idSetor)
);

CREATE SEQUENCE WLAR_SETOR_SQ
  MINVALUE 1
  MAXVALUE 999999
  START WITH 1
  INCREMENT BY 1
  NOCACHE
  CYCLE;

CREATE TRIGGER WLAR_SETOR_TG
    BEFORE INSERT ON WLAR_SETOR
    FOR EACH ROW
    BEGIN
        SELECT WLAR_SETOR_SQ.NEXTVAL
            INTO :new.idSetor FROM DUAL;
    END;

CREATE TABLE WLAR_trabalha (
    matricula NUMBER(8) NOT NULL,
	idSetor NUMBER(6) NOT NULL,
    dataHora TIMESTAMP(0) NOT NULL,
    duracao NUMBER(4) NOT NULL,
    CONSTRAINT trabalha_PK PRIMARY KEY (matricula, dataHora),
    CONSTRAINT trabalha_SETOR_FK FOREIGN KEY (idSetor)
        REFERENCES WLAR_SETOR (idSetor),
    CONSTRAINT trabalha_PLANTONISTA_FK FOREIGN KEY (matricula)
        REFERENCES WLAR_PLANTONISTA (matricula)
);

CREATE TABLE WLAR_ESPECIALIDADE (
    codEspecialidade NUMBER(6) NOT NULL,
    nomeEspecialidade VARCHAR2(50) NOT NULL,
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (codEspecialidade)
);

CREATE TABLE WLAR_tem (
    matricula NUMBER(8) NOT NULL,
    codEspecialidade NUMBER(6) NOT NULL,
    CONSTRAINT tem_PK PRIMARY KEY (matricula, codEspecialidade),
    CONSTRAINT tem_ESPECIALIDADE_FK FOREIGN KEY (codEspecialidade) 
        REFERENCES WLAR_ESPECIALIDADE (codEspecialidade),
    CONSTRAINT tem_PLANTONISTA_FK FOREIGN KEY (matricula) 
        REFERENCES WLAR_PLANTONISTA (matricula)
);
