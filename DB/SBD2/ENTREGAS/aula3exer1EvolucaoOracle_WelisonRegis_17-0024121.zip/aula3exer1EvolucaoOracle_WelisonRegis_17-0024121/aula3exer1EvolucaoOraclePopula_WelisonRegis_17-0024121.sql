--  ----------------------- PLANTONISTA ---------------------------
--                                                                   
--                    SCRIPT POPULA (DML)                            
--                                                                   
-- Data Criacao ..........: 06/10/2019                               
-- Autor(es) .............: Welison Regis
-- Banco de Dados ........: Oracle                                    
-- Base de Dados(nome) ...: aula3exer1EvolucaoOracle aula3exer1EvolucaoOracle                                                                                      
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 5 Tabelas
--         => 1 Visao
--         => 1 Sequencia
--         => 1 Trigger                                              
--                                                                   
-- ----------------------------------------------------------------- 

INSERT ALL
    INTO WLAR_PLANTONISTA VALUES (12345, 'Jorge Matheus da Silva', 'M')
    INTO WLAR_PLANTONISTA VALUES (12346, 'Emanuel Richster Roussef', 'M')
    INTO WLAR_PLANTONISTA VALUES (12347, 'Alexandre de Moraes', 'M')
    SELECT * FROM DUAL;

INSERT ALL
    INTO WLAR_SETOR(nomeSetor) VALUES ('Emergência')
    INTO WLAR_SETOR(nomeSetor) VALUES ('Ambulatório')
    INTO WLAR_SETOR(nomeSetor) VALUES ('Fisioterapia')
    SELECT * FROM DUAL;

INSERT ALL
    INTO WLAR_trabalha VALUES (12345, 1, TIMESTAMP '2019-05-28 15:00:00', 720)
    INTO WLAR_trabalha VALUES (12346, 2, TIMESTAMP '2019-05-27 19:30:00', 480)
    INTO WLAR_trabalha VALUES (12347, 3, TIMESTAMP '2019-05-27 20:00:00', 480)
    SELECT * FROM DUAL;

INSERT ALL
    INTO WLAR_ESPECIALIDADE VALUES (1000, 'Cuidados Intensivos')
    INTO WLAR_ESPECIALIDADE VALUES (1001, 'Oncologia')
    INTO WLAR_ESPECIALIDADE VALUES (1002, 'Clínica e Cirúrgica')
    INTO WLAR_ESPECIALIDADE VALUES (1003, 'Nefrologia')
    SELECT * FROM DUAL;

INSERT ALL
    INTO WLAR_tem VALUES (12345, 1000)
    INTO WLAR_tem VALUES (12345, 1001)
    INTO WLAR_tem VALUES (12346, 1002)
    INTO WLAR_tem VALUES (12347, 1003)
    SELECT * FROM DUAL;
