-- --------     << VENDAS >>     ------------
-- 
--                    SCRIPT DE APAGA (DDL)
-- 
-- Data Criacao ...........: 18/08/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis, 17/0024121
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula1exer2
-- 
-- Data Ultima Alteracao ..: 19/08/2019
--   => Criacao do script de apagar
--   => Correcao na tabela vende
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula1exer2;

DROP TABLE vende;
DROP TABLE atua;
DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE supervisiona;
DROP TABLE telefone;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;
DROP TABLE PESSOA;

