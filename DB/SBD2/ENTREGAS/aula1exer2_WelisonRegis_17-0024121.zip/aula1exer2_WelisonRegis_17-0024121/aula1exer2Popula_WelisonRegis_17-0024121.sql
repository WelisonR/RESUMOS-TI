-- --------     << VENDAS >>     ------------
-- 
--                    SCRIPT DE POPULA (DML)
-- 
-- Data Criacao ...........: 18/08/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis, 17/0024121
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula1exer2
-- 
-- Data Ultima Alteracao ..: 19/08/2019
--   => Criacao do script de popula
--   => Correcao na tabela vende
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula1exer2;

INSERT INTO PESSOA VALUES
	-- GERENTES
	(02376933321, 'João Alencar da Silva', 'encryptedpass'),
    (01231231211, 'Maria Rosa da Fonseca', 'senhadaRosa'),
    (92137123211, 'João Guilherme Toscano', 'Toscano123@'),
    -- EMPREGADOS
    (12390120932, 'Waldemiro Santos Souza', 'valdinho1@'),
    (93127381232, 'Guilherme Santos de Alcantara', 'alcantara1313'),
    (76152812312, 'João Batista Silva Neto', 'silvinhaneto@');

INSERT INTO GERENTE VALUES
	('joaoalencar12@gmail.com', 'superior', 02376933321),
    ('mariafonseca99@uol.com.br', 'fundamental', 01231231211),
    ('joaoguigui@yahoo.com.br', 'médio', 92137123211);

INSERT INTO EMPREGADO VALUES
	(1, 12390120932, 33, 'Itamaracá', 'Setor Sul', 'Gama', 'DF', 72000000),
    (2, 93127381232, 12, 'Santo Antônio', 'Zona Leste', 'Ceilândia', 'DF', 31241200),
    (3, 76152812312, 13, 'Tiradentes', 'Setor Norte', 'Santa Maria', 'DF', 89132122);

INSERT INTO telefone VALUES
	(1, 55061999911234),
    (2, 55061987172312),
    (3, 55061997318231);

INSERT INTO supervisiona VALUES
	(02376933321, 1),
    (01231231211, 2),
    (92137123211, 3);

INSERT INTO AREA VALUES
	(1, 'Eletrodoméstico'),
    (2, 'Informática'),
    (3, 'Papelaria');

INSERT INTO PRODUTO VALUES
	(1, 1, 'Máquina de Lavar Brastemp 11kg'),
    (2, 2, 'Novo Inspiron 15 3000'),
    (3, 3, 'Papel Sulfite 75g Alcalino 210x297 A4 500F');

INSERT INTO atua VALUES
	(1, 1),
    (2, 2),
    (3, 3);

INSERT INTO vende VALUES
	(1, 1, 1, 1500.00, '2019-08-17 08:02:01'),
    (2, 2, 2, 1200.00, '2019-08-18 10:04:03'),
    (3, 3, 10, 20.00, '2019-08-18 10:11:08');
