-- --------------     << DISCIPLINAS >>     ---------------------
--
--                    SCRIPT DE CONTROLE (DCL)
--
-- Data Criacao ...........: 21/10/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: WelisonRegis
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuários
--         => 01 Visao
--
-- -----------------------------------------------------------------

-- ADMIN: Administrador da base de dados, possui todos os privilegios, tanto DDL quanto DML
CREATE USER 'ADMIN' IDENTIFIED BY 'AdminMaster1@2';
GRANT  ALL PRIVILEGES ON WelisonRegis.* TO 'ADMIN';

-- PESSOA: Usuário comum da base de dados. Acesso apenas às consultas DML
CREATE USER 'PESSOA' IDENTIFIED BY 'PessoaTop1@2';
GRANT SELECT, INSERT, DELETE, UPDATE ON WelisonRegis.* TO 'PESSOA';