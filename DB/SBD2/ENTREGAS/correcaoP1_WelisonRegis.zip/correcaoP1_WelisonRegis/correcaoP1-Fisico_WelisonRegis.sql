-- --------------     << DISCIPLINAS >>     ---------------------
--
--                    SCRIPT FISICO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: WelisonRegis
--
-- Ultima modificacao: 22/10/2019
--   => Correção de script de criação
--   => Ajustes na modelagem pós-revisão (22/10/19)
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--         => 02 Usuários
--         => 01 Visao
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS WelisonRegis;
USE WelisonRegis;

CREATE TABLE PROFESSOR (
    idProfessor INT NOT NULL AUTO_INCREMENT,
    primeiroNome VARCHAR(50) NOT NULL,
    ultimoNome VARCHAR(50) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
CONSTRAINT PROFESSOR_PK PRIMARY KEY (idProfessor)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE DISCIPLINA (
    idDisciplina INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    sigla VARCHAR(50) NOT NULL,
    qtCredito INT NOT NULL,
    periodo ENUM('M', 'V', 'N') NOT NULL,
CONSTRAINT DISCIPLINA_PK PRIMARY KEY (idDisciplina)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE email (
    idProfessor INT NOT NULL,
    email VARCHAR(50) NOT NULL,
CONSTRAINT email_PK PRIMARY KEY (idProfessor, email),
CONSTRAINT email_PROFESSOR_FK FOREIGN KEY (idProfessor)
  REFERENCES PROFESSOR (idProfessor)
) ENGINE=InnoDB;

CREATE TABLE necessita (
    idDisciplina INT NOT NULL,
    idDisciplinaRequisito INT NOT NULL,
CONSTRAINT necessita_DISCIPLINA_FK FOREIGN KEY (idDisciplina)
  REFERENCES DISCIPLINA (idDisciplina),
CONSTRAINT necessita_DISCIPLINA2_FK FOREIGN KEY (idDisciplinaRequisito)
  REFERENCES DISCIPLINA (idDisciplina)
) ENGINE=InnoDB;

CREATE TABLE leciona (
    idProfessor INT NOT NULL,
    idDisciplina INT NOT NULL,
CONSTRAINT leciona_PK PRIMARY KEY (idProfessor, idDisciplina),
CONSTRAINT leciona_PROFESSOR_FK FOREIGN KEY (idProfessor)
  REFERENCES PROFESSOR (idProfessor),
CONSTRAINT leciona_DISCIPLINA_FK FOREIGN KEY (idDisciplina)
  REFERENCES DISCIPLINA (idDisciplina)
) ENGINE=InnoDB;
