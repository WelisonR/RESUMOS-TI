-- --------     << aula4extra1 >>     ------------
-- 
--                    SCRIPT APAGA (DDL)
-- 
-- Data Criacao ...........: 04/09/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula4extra1
-- 
-- Data Ultima Alteracao ..: 04/09/2019
--   => Criacao do script de apaga
-- 
-- PROJETO => 01 Base de Dados
-- 
-- -----------------------------------------------------------------

USE aula4extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;