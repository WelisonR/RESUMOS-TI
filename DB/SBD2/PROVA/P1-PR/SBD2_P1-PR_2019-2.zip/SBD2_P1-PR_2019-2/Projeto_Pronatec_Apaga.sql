﻿-- ------------------------------------------------------
-- Projeto no Banco MySQL
-- Origem: http://dados.gov.br/dataset/mec-pronatec-eptc
-- Base de Dados = pronatec
--   01 = Base de Dados
--   04 = Tabelas
-- ------------------------------------------------------

USE pronatec;

DROP TABLE dados_errados;

DROP TABLE matriculados;

DROP TABLE concluintes;

DROP TABLE unidades;