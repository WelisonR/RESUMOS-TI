-- --------     << TF1 >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 25/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis,
--                           Rafael Makaha Gomes Ferreira
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: TF1_Aval
-- 
-- Data Ultima Alteracao ..: 25/06/2019
--   => Adiciona o script de criacao
-- 
-- PROJETO => 01 Base de Dados
--         => 11 tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS TF1_Aval;

USE TF1_Aval;


CREATE TABLE EMPRESA (
    cnpj NUMERIC(14) NOT NULL,
    nomeFantasia VARCHAR(30) NOT NULL,
    razaoSocial VARCHAR(100) NOT NULL,
    cep NUMERIC(8) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    siglaEstado VARCHAR(2) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    complemento VARCHAR(100),
    inscricaoEstadual NUMERIC(8) NOT NULL,
    email VARCHAR(30) NOT NULL,
    telefone NUMERIC(12) NOT NULL,
CONSTRAINT EMPRESA_PK PRIMARY KEY (cnpj)
) ENGINE = InnoDB;

CREATE TABLE FORNECEDOR (
    cnpj NUMERIC(14) NOT NULL,
    tipoPagamento ENUM('A', 'D') NOT NULL,
CONSTRAINT FORNECEDOR_PK PRIMARY KEY (cnpj),
CONSTRAINT FORNECEDOR_EMPRESA_FK FOREIGN KEY (cnpj)
REFERENCES EMPRESA (cnpj)
) ENGINE = InnoDB;
 
CREATE TABLE REPRESENTANTE (
    cnpj NUMERIC(14) NOT NULL,
CONSTRAINT REPRESENTANTE_PK PRIMARY KEY (cnpj),
CONSTRAINT REPRESENTANTE_EMPRESA_FK FOREIGN KEY (cnpj)
REFERENCES EMPRESA (cnpj)
) ENGINE = InnoDB;

CREATE TABLE CLIENTE (
    cnpj NUMERIC(14) NOT NULL,
    dataCadastro DATETIME NOT NULL,
    ultimaVisita DATETIME NOT NULL,
    proximaVisita DATETIME,
    codigoBanco NUMERIC(2) NOT NULL,
    agencia NUMERIC(5) NOT NULL,
    conta NUMERIC(7) NOT NULL,
CONSTRAINT CLIENTE_PK PRIMARY KEY (cnpj),
CONSTRAINT CLIENTE_EMPRESA_FK FOREIGN KEY (cnpj)
REFERENCES EMPRESA (cnpj)
) ENGINE = InnoDB;

CREATE TABLE PEDIDO (
    idPedido INTEGER NOT NULL AUTO_INCREMENT,
    representante NUMERIC(14) NOT NULL,
    cliente NUMERIC(14) NOT NULL,
    dataEntrega DATETIME,
    status ENUM('P', 'E', 'C', 'S') NOT NULL,
    dataPedido DATETIME NOT NULL,
CONSTRAINT PEDIDO_PK PRIMARY KEY (idPedido),
CONSTRAINT PEDIDO_REPRESENTANTE_FK FOREIGN KEY (representante)
REFERENCES REPRESENTANTE (cnpj),
CONSTRAINT PEDIDO_CLIENTE_FK FOREIGN KEY (cliente)
REFERENCES CLIENTE (cnpj)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PRODUTO (
    codigoProduto INTEGER NOT NULL,
    fornecedor NUMERIC(14) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    precoBase DECIMAL(8,2) NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    comissao DECIMAL(5,3) NOT NULL,
    quantidadeMinima INTEGER NOT NULL,
CONSTRAINT PRODUTO_PK PRIMARY KEY (codigoProduto),
CONSTRAINT PRODUTO_FORNECEDOR_FK FOREIGN KEY (fornecedor)
REFERENCES FORNECEDOR (cnpj)
) ENGINE = InnoDB;

CREATE TABLE estoca (
    produto INTEGER NOT NULL,
    cliente NUMERIC(14) NOT NULL,
    quantidade INTEGER NOT NULL,
    comentario VARCHAR(150) NOT NULL,
CONSTRAINT estoca_PK PRIMARY KEY (produto, cliente),
CONSTRAINT estoca_PRODUTO_FK FOREIGN KEY (produto)
REFERENCES PRODUTO (codigoProduto),
CONSTRAINT estoca_CLIENTE_FK FOREIGN KEY (cliente)
REFERENCES CLIENTE (cnpj)
) ENGINE = InnoDB;

CREATE TABLE PAGAMENTO (
    idPagamento INTEGER NOT NULL AUTO_INCREMENT,
    pedido INTEGER NOT NULL,
    dataPagamento DATE NOT NULL,
    total DECIMAL(8,2) NOT NULL,
    dataVencimento DATE NOT NULL,
CONSTRAINT PAGAMENTO_PK PRIMARY KEY (idPagamento),
CONSTRAINT PAGAMENTO_PEDIDO_FK FOREIGN KEY (pedido)
REFERENCES PEDIDO (idPedido)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


CREATE TABLE ITEM (
    produto INTEGER NOT NULL,
    pedido INTEGER NOT NULL,
    quantidade INTEGER NOT NULL,
    precoUnitario DECIMAL(8,2) NOT NULL,
CONSTRAINT ITEM_PK PRIMARY KEY (pedido, produto),
CONSTRAINT ITEM_PRODUTO_FK FOREIGN KEY (produto)
REFERENCES PRODUTO (codigoProduto),
CONSTRAINT ITEM_PEDIDO_FK FOREIGN KEY (pedido)
REFERENCES PEDIDO (idPedido)
) ENGINE = InnoDB;

CREATE TABLE CATEGORIA (
    idCategoria INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    descricao VARCHAR(50) NOT NULL,
CONSTRAINT CATEGORIA_PK PRIMARY KEY (idCategoria)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE possui (
    categoria INTEGER NOT NULL,
    produto INTEGER NOT NULL,
CONSTRAINT possui_PK PRIMARY KEY (categoria, produto),
CONSTRAINT possui_CATEGORIA_FK FOREIGN KEY (categoria)
REFERENCES CATEGORIA (idCategoria),
CONSTRAINT possui_PRODUTO_FK FOREIGN KEY (produto)
REFERENCES PRODUTO (codigoProduto)
) ENGINE = InnoDB;