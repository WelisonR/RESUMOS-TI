-- --------     << TF1G >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 02/07/2019
-- Autor(es) ..............: Gabriel Batista Albino Silva, 16/0028361
--                           Rafael Makaha Gomes Ferreira, 16/0142369
--                           Vinicius de Castro Cantuária, 14/0165169
--                           Welison Lucas Almeida Regis, 17/0024121
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: TF1G
-- 
-- Data Ultima Alteracao ..: 03/07/2019
--   => Criacao do script de criacao
--   => Adicao de tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
--         => 01 Visao
-- 
-- -----------------------------------------------------------------


CREATE DATABASE IF NOT EXISTS TF1G;

USE TF1G;


CREATE TABLE EMPRESA (
    cnpj BIGINT(14) NOT NULL,
    inscricaoEstadual BIGINT(10) NOT NULL,
    nomeComercial VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    numero INT(5) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    cep INT(8) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,

    CONSTRAINT EMPRESA_PK
    PRIMARY KEY (cnpj),

    CONSTRAINT EMPRESA_U
    UNIQUE (inscricaoEstadual)
) ENGINE=InnoDB;

CREATE TABLE telefone (
    cnpj BIGINT(14) NOT NULL,
    telefone BIGINT(14) NOT NULL,

    CONSTRAINT telefone_PK
    PRIMARY KEY (cnpj, telefone),

    CONSTRAINT telefone_EMPRESA_FK
    FOREIGN KEY (cnpj)
    REFERENCES EMPRESA (cnpj)
) ENGINE=InnoDB;

CREATE TABLE REPRESENTANTE (
    cnpj BIGINT(14) NOT NULL,
    core INT(7) NOT NULL,

    CONSTRAINT REPRESENTANTE_PK
    PRIMARY KEY (cnpj),

    CONSTRAINT REPRESENTANTE_EMPRESA_FK
    FOREIGN KEY (cnpj)
    REFERENCES EMPRESA (cnpj),

    CONSTRAINT REPRESENTANTE_U
    UNIQUE (core)
) ENGINE=InnoDB;

CREATE TABLE FUNCIONARIO (
    cpf BIGINT(11) NOT NULL,
    dtAdmissao DATE NOT NULL,
    cnpj BIGINT(14) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    nomeUsuario VARCHAR(50) NOT NULL,
    dtNascimento DATE NOT NULL,
    telefone BIGINT(14) NOT NULL,
    salario DECIMAL(8, 2) NOT NULL,
    numero INT(5) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    cep INT(8) NOT NULL,
    logradouro VARCHAR(50) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    dtDemissao DATE,

    CONSTRAINT FUNCIONARIO_PK
    PRIMARY KEY (cpf, dtAdmissao),

    CONSTRAINT FUNCIONARIO_REPRESENTANTE_FK
    FOREIGN KEY (cnpj)
    REFERENCES REPRESENTANTE (cnpj)
) ENGINE=InnoDB;

CREATE TABLE FORNECEDOR (
    cnpj BIGINT(14) NOT NULL,
    cnpjRepresentante BIGINT(14) NOT NULL,
    dtInicio DATE NOT NULL,
    statusFornecedor ENUM('ativo', 'inativo') NOT NULL,

    CONSTRAINT FORNECEDOR_PK
    PRIMARY KEY (cnpj),

    CONSTRAINT FORNECEDOR_EMPRESA_FK
    FOREIGN KEY (cnpj)
    REFERENCES EMPRESA (cnpj),

    CONSTRAINT FORNECEDOR_REPRESENTANTE_FK
    FOREIGN KEY (cnpjRepresentante)
    REFERENCES REPRESENTANTE (cnpj)
) ENGINE=InnoDB;

CREATE TABLE regiaoRepresentada (
    cnpj BIGINT(14) NOT NULL,
    regiaoRepresentada VARCHAR(50) NOT NULL,

    CONSTRAINT regiaoRepresentada_PK
    PRIMARY KEY (cnpj, regiaoRepresentada),

    CONSTRAINT regiaoRepresentada_FORNECEDOR_FK
    FOREIGN KEY (cnpj)
    REFERENCES FORNECEDOR (cnpj)
) ENGINE=InnoDB;

CREATE TABLE CLIENTE (
    cnpj BIGINT(14) NOT NULL,
    dtCadastro DATE NOT NULL,
    statusCliente ENUM('ativo', 'inativo') NOT NULL,

    CONSTRAINT CLIENTE_PK
    PRIMARY KEY (cnpj),

    CONSTRAINT CLIENTE_EMPRESA_FK
    FOREIGN KEY (cnpj)
    REFERENCES EMPRESA (cnpj)
) ENGINE=InnoDB;

CREATE TABLE limita (
    cnpjCliente BIGINT(14) NOT NULL,
    cnpjFornecedor BIGINT(14) NOT NULL,
    limiteCredito DECIMAL(8,2) NOT NULL,

    CONSTRAINT limita_PK
    PRIMARY KEY (cnpjCliente, cnpjFornecedor),

    CONSTRAINT limita_CLIENTE_FK
    FOREIGN KEY (cnpjCliente)
    REFERENCES CLIENTE (cnpj),

    CONSTRAINT limita_FORNECEDOR_FK
    FOREIGN KEY (cnpjFornecedor)
    REFERENCES FORNECEDOR (cnpj)
) ENGINE=InnoDB;

CREATE TABLE RELATORIO (
    idRelatorio INT NOT NULL AUTO_INCREMENT,
    cnpjRepresentante BIGINT(14) NOT NULL,
    cnpjCliente BIGINT(14) NOT NULL,
    dtRelatorio DATE NOT NULL,
    comentario VARCHAR(500),
    dtProximaVisita DATE,

    CONSTRAINT RELATORIO_PK
    PRIMARY KEY (idRelatorio),

    CONSTRAINT RELATORIO_REPRESENTANTE_FK
    FOREIGN KEY (cnpjRepresentante)
    REFERENCES REPRESENTANTE (cnpj),

    CONSTRAINT RELATORIO_CLIENTE_FK
    FOREIGN KEY (cnpjCliente)
    REFERENCES CLIENTE (cnpj)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE PEDIDO (
    idPedido INT NOT NULL AUTO_INCREMENT,
    idRelatorio INT NOT NULL,
    dtPedido DATE NOT NULL,
    dtVencimentoPagamento DATE NOT NULL,
    dtPagamentoClienteFornecedor DATE,
    dtPagamentoFornecedorRepresentante DATE,
    statusEntrega ENUM('entregue', 'pendente', 'cancelado') NOT NULL,

    CONSTRAINT PEDIDO_PK
    PRIMARY KEY (idPedido),

    CONSTRAINT PEDIDO_RELATORIO_FK
    FOREIGN KEY (idRelatorio)
    REFERENCES RELATORIO (idRelatorio)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE CATEGORIA (
    idCategoria INT NOT NULL AUTO_INCREMENT,
    nomeCategoria VARCHAR(50) NOT NULL,
    descricaoCategoria VARCHAR(100) NOT NULL,

    CONSTRAINT CATEGORIA_PK
    PRIMARY KEY (idCategoria)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE PRODUTO (
    idProduto INT NOT NULL AUTO_INCREMENT,
    cnpj BIGINT(14) NOT NULL,
    idCategoria INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    preco DECIMAL(8, 2) NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    statusProduto ENUM('ativo', 'inativo') NOT NULL,
    qtdeMinima INT(8) NOT NULL,
    taxaComissao DECIMAL(4, 2) NOT NULL,
    metaVenda DECIMAL(8, 2),

    CONSTRAINT PRODUTO_PK
    PRIMARY KEY (idProduto),

    CONSTRAINT PRODUTO_FORNECEDOR_FK
    FOREIGN KEY (cnpj)
    REFERENCES FORNECEDOR (cnpj),

    CONSTRAINT PRODUTO_CATEGORIA_FK
    FOREIGN KEY (idCategoria)
    REFERENCES CATEGORIA (idCategoria)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE contem (
    idPedido INT NOT NULL,
    idProduto INT NOT NULL,
    quantidade INT(8) NOT NULL,
    precoVenda DECIMAL(8, 2) NOT NULL,

    CONSTRAINT contem_PK
    PRIMARY KEY (idPedido, idProduto),

    CONSTRAINT contem_PEDIDO_FK
    FOREIGN KEY (idPedido)
    REFERENCES PEDIDO (idPedido),

    CONSTRAINT contem_PRODUTO_FK
    FOREIGN KEY (idProduto)
    REFERENCES PRODUTO (idProduto)
) ENGINE=InnoDB;

CREATE TABLE estoca (
    cnpj BIGINT(14) NOT NULL,
    idProduto INT NOT NULL,
    qtdeMinima INT(8) NOT NULL,
    quantidade INT(8) NOT NULL,
    dtChecagem TIMESTAMP NOT NULL,

    CONSTRAINT estoca_PK
    PRIMARY KEY (idProduto, cnpj),

    CONSTRAINT estoca_CLIENTE_FK
    FOREIGN KEY (cnpj)
    REFERENCES CLIENTE (cnpj),

    CONSTRAINT estoca_PRODUTO_FK
    FOREIGN KEY (idProduto)
    REFERENCES PRODUTO (idProduto)
) ENGINE=InnoDB;

CREATE TABLE PAGAMENTO(
    idVencimento INT(4) NOT NULL AUTO_INCREMENT,
    dtPagamento timestamp NOT NULL,
    valorSalario DECIMAL(7,2) NOT NULL,
    formaPagamento ENUM('D','T') NOT NULL,
    descPagamento varchar(50) NOT NULL,
    cpf BIGINT(11) NOT NULL,
    dtAdmissao date NOT NULL,

    CONSTRAINT PAGAMENTO_PK
    PRIMARY KEY (idVencimento),

    CONSTRAINT PAGAMENTO_FUNCIONARIO_FK
    FOREIGN KEY (cpf, dtAdmissao)
    REFERENCES FUNCIONARIO (cpf, dtAdmissao)
) ENGINE=InnoDB;
