-- --------     << TF1G >>     ------------
-- 
--                    SCRIPT DE CONTROLE (DDL)
-- 
-- Data Criacao ...........: 03/07/2019
-- Autor(es) ..............: Gabriel Batista Albino Silva, 16/0028361
--                           Rafael Makaha Gomes Ferreira, 16/0142369
--                           Vinicius de Castro Cantuária, 14/0165169
--                           Welison Lucas Almeida Regis, 17/0024121
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: TF1G
-- 
-- Data Ultima Alteracao ..: 03/07/2019
--   => Criacao do script de controle
-- 
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
--         => 01 Visao
-- 
-- -----------------------------------------------------------------

CREATE USER admin1
IDENTIFIED BY 'admin1';

GRANT ALL PRIVILEGES
ON TF1G.*
TO 'admin1';
