-- --------     << TF1G >>     ------------
--
-- Data Criacao ...........: 03/07/2019
-- Autor(es) ..............: Gabriel Batista Albino Silva, 16/0028361
--                           Rafael Makaha Gomes Ferreira, 16/0142369
--                           Vinicius de Castro Cantuária, 14/0165169
--                           Welison Lucas Almeida Regis, 17/0024121
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: TF1G
--
-- Data Ultima Alteracao ..: 03/07/2019
--   => Criacao do script de consulta
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
--         => 01 Visao
--
-- -----------------------------------------------------------------

USE TF1G;

# Visualiza todos os produtos e suas respectivas categorias.

SELECT P.idProduto AS CodigoProduto,
       P.cnpj AS CNPJ,
       P.nome AS Nome,
       P.preco AS Preco,
       P.descricao AS Descricao,
       P.statusProduto AS StatusProduto,
       P.qtdeMinima AS QuantidadeMinima,
       P.taxaComissao AS TaxaComissao,
       P.metaVenda AS MetaVenda,
       C.idCategoria AS CodigoCategoria,
       C.nomeCategoria AS NomeCategoria
FROM PRODUTO AS P
INNER JOIN CATEGORIA AS C
ON P.idCategoria = C.idCategoria
ORDER BY P.idProduto, C.idCategoria;


# Visualiza todos os pedidos e os produtos contidos neles.

CREATE VIEW vwPedido AS
SELECT P.idPedido AS CodigoPedido,
       P.dtPedido AS DataPedido,
       P.dtVencimentoPagamento AS DataVencimento,
       P.dtPagamentoClienteFornecedor AS DataPagamento,
       P.statusEntrega AS StatusEntrega,
       PR.idProduto AS CodigoProduto,
       PR.nome AS Nome,
       c.quantidade AS Quantidade,
       c.precoVenda AS PrecoVenda,
       (c.quantidade * PR.preco) AS ValorTotal
FROM contem AS c
INNER JOIN PEDIDO AS P
ON P.idPedido = c.idPedido
INNER JOIN PRODUTO AS PR
ON c.idProduto = PR.idProduto;
