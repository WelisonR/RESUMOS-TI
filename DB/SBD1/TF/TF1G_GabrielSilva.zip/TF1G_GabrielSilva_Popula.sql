-- --------     << TF1G >>     ------------
-- 
--                    SCRIPT DE POPULAR (DDL)
-- 
-- Data Criacao ...........: 02/07/2019
-- Autor(es) ..............: Gabriel Batista Albino Silva, 16/0028361
--                           Rafael Makaha Gomes Ferreira, 16/0142369
--                           Vinicius de Castro Cantuária, 14/0165169
--                           Welison Lucas Almeida Regis, 17/0024121
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: TF1G
-- 
-- Data Ultima Alteracao ..: 03/07/2019
--   => Criacao do script de popular
--   => Adiciona mais registros às tabelas; popula nova tabela PAGAMENTO
-- 
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
--         => 01 Visao
-- 
-- -----------------------------------------------------------------


USE TF1G;

INSERT INTO EMPRESA VALUES
	-- LUIS
	(21028310000194, 1012312101, 'Luis Representante',  'luisrepresenta@gmail.com', 1, 'Setor Autárquico', 32440503, 'Rua Tiradentes', 'DF', 'Casa', 'Gama'),
	-- CLIENTES
    (46108561000100, 1312412414, 'Rei da Camiseta', 'reidacamiseta@email.com', 4, 'Concessionárias', 36038453, 'Avenida das Castanheiras', 'DF', 'Lote 14, próximo ao shopping Felicitta', 'Águas Claras'),
    (51376107000170, 1401293812, 'Reino das Rações', 'reinodasracoes@email.com', 2, 'Asa Norte', 36031456, '712 norte', 'DF', 'Lote 14, próximo ao supercei', 'Asa Norte'),
	(81413102000130, 1051241123, 'Demacol', 'demacol@email.com', 1, 'QNS', 71100001, 'rua 2', 'DF', 'lote 1, próximo ao supercei', 'Ceilândia' ),
    (28193727000151, 1089123123, 'PetShop Maria', 'marypet@email.com', 11, 'Setor Sul', 71100004, 'rua Carlos Magno', 'DF', 'lote 11, próximo a UnB-Gama', 'Gama' ),
    (53354797000191, 1090121231, 'Acessórios musicais Júnior', 'juninhomusical@email.com', 1, 'Setor Norte', 36001300, 'Avenida Brasil', 'DF', 'Loteamento 1, próximo a BR 020', 'Taguatinga'),
	-- FORNECEDORES
	(97164264000112, 1032124012, 'PetCenter JMA Fornecedora',  'petshopmaria@gmail.com', 33, 'Setor Norte', 72400000, 'Itamaracá', 'DF', 'Casa', 'Gama'),
	(14735279000166, 1035912901, 'Casa dos bichos', 'pethousek@email.com', 14, 'QNQ', 71100003, 'Rua Sete de Setembro', 'DF', '´lote 14, próximo a empresa AMBEV', 'Taguatinga'),
    (71352673000159, 1042141912, 'Home Center', 'homecenter@email.com', 24, 'SIA', 71100004, 'trecho 4', 'DF', 'lote 24, próximo a BR-040', 'SIA' ),
    (53448711000190, 1110932131, 'Camisas Leais', 'camisasleais@email.com', 11, 'Setor Sul', 36031225, 'Avenida Borboleta', 'DF', 'Lote 14, próximo a feira do Gama', 'Gama'),
    (75190619000105, 1231239121, 'Teclados Musicais Bonitos', 'tecladosbonitos@email.com', 9, 'Arniqueiras', 36031456, 'Avenida Araucárias', 'DF', 'Lote 14' 'próximo ao BigBox', 'Samambaia');

INSERT INTO telefone VALUES
	(21028310000194, 55061984362231),
	(21028310000194, 55061995392231),
	(97164264000112, 55061995361221),
	(97164264000112, 55061985363231),
	(14735279000166, 55061985368261),
	(71352673000159, 55061995361281),
	(81413102000130, 05506132361271),
	(28193727000151, 05506131381731),
	(28193727000151, 05506139261231),
    (53354797000191, 55061938140989),
    (28193727000151, 55061991231251),
    (53354797000191, 55061989123124),
    (53448711000190, 55061990999112),
    (75190619000105, 55061993123121);

-- TUPLA ÚNICA, POIS REPRESENTA APENAS O LUÍS
INSERT INTO REPRESENTANTE VALUES
	(21028310000194, 3877652);

INSERT INTO FUNCIONARIO VALUES
	(84489381000, '2018-02-18', 21028310000194, 'João Alvés da Silva Damasceno', 'JOAOJM', '2000-03-23', 55061996781876, 1200.00, 33, 'Setor Sul', 67000123, 'Rua Buruti', 'DF', 'Casa', 'Gama', NULL),
    (30978251008, '2016-03-22', 21028310000194, 'Maria da Silvinha Sousa', 'MARYMM', '1998-06-13', 55061985612100, 1200.00, 19, 'Setor Oeste', 73005200, 'Rua Itamaracá', 'DF', 'Casa', 'Gama', '2018-01-19'),
    (12709034034, '2014-09-03', 21028310000194, 'Lúcio Costa Pereira', 'LUCINHO', '1996-03-30', 55061967871232, 1200.00, 03, 'Setor X', 34001321, 'Rua Matos Brasil', 'DF', 'Apartamento', 'Gama', '2016-02-15'),
    (12312412112, '2013-09-02', 21028310000194, 'Lúcio Costa Pereira', 'LUCINHO', '1996-03-30', 55061967871232, 1200.00, 03, 'Setor X', 34001321, 'Rua Matos Brasil', 'DF', 'Apartamento', 'Gama', '2014-08-03'),
	(41241211231, '2012-08-14', 21028310000194, 'Lúcio Costa Pereira', 'LUCINHO', '1996-03-30', 55061967871232, 1200.00, 03, 'Setor X', 34001321, 'Rua Matos Brasil', 'DF', 'Apartamento', 'Gama', '2013-08-02');

-- CNPJs 97164264000112, 14735279000166, 71352673000159, 53448711000190, 75190619000105 são fornecedores
INSERT INTO FORNECEDOR VALUES
	(97164264000112, 21028310000194, '2017-09-13', 'ativo'),
    (14735279000166, 21028310000194, '2019-06-19', 'ativo'),
    (71352673000159, 21028310000194, '2011-12-30', 'ativo'),
    (53448711000190, 21028310000194, '2010-03-13', 'inativo'),
    (75190619000105, 21028310000194, '2009-05-15', 'ativo');

INSERT INTO regiaoRepresentada VALUES
	(97164264000112, 'Gama'),
    (97164264000112, 'Valparaiso'),
    (14735279000166, 'Samambaia'),
    (71352673000159, 'Taguatinga'),
    (53448711000190, 'Valparaiso'),
    (75190619000105, 'Gama');

-- CNPJs 81413102000130, 28193727000151, 53354797000191, 46108561000100 e 51376107000170 são clientes
INSERT INTO CLIENTE VALUES
	(81413102000130, '2017-03-19', 'ativo'),
    (28193727000151, '2000-12-29', 'ativo'),
    (53354797000191, '2012-05-12', 'ativo'),
    (46108561000100, '2001-03-14', 'inativo'),
    (51376107000170, '2000-01-16', 'ativo');

INSERT INTO limita VALUES
	(51376107000170, 97164264000112, 135000.00),
    (28193727000151, 14735279000166, 190300.00),
    (81413102000130, 71352673000159, 35000.00),
    (46108561000100, 53448711000190, 150000.00),
    (53354797000191, 75190619000105, 13100.00);

INSERT INTO RELATORIO VALUES
	(NULL, 21028310000194, 81413102000130, '2019-02-19', 'Necessidade de reposição se mantém constante. A nova administração da loja está com bom desempenho', '2019-03-19'),
    (NULL, 21028310000194, 81413102000130, '2019-01-19', 'Vendas estão constantes e consistentes. Continuar verificação mensal das necessidades do cliente', '2019-02-19'),
    (NULL, 21028310000194, 28193727000151, '2019-02-20', 'Poucas vendas dos produtos fornecidos. Foi orientado como melhor dispor os produtos. Verificar novamente o desempenho do cliente em um período de tempo menor', '2019-03-05'),
    (NULL, 21028310000194, 53354797000191, '2019-02-25', 'Bom desempenho de venda. A demanda por produtos continua com a mesma consistência', '2019-03-13'),
    (NULL, 21028310000194, 46108561000100, '2019-03-10', 'Desempenho satisfatório. Necessário perguntar ao fornecedor sobre a disponibilidade dos produtos da área de interesse do cliente', '2019-03-20');

INSERT INTO PEDIDO VALUES
	(NULL, 1, '2019-03-15', '2019-03-22', NULL, NULL, 'pendente'),
    (NULL, 2, '2019-01-10', '2019-01-30', '2019-02-23', '2019-02-27', 'entregue'),
    (NULL, 3, '2018-11-14', '2018-11-20', '2019-12-14', '2018-12-14', 'entregue'),
    (NULL, 4, '2019-03-15', '2019-03-25', '2019-04-10', '2019-04-20', 'pendente'),
    (NULL, 5, '2019-04-10', '2019-04-25', NULL, NULL, 'cancelado');

INSERT INTO CATEGORIA VALUES
	(NULL, 'PetShop', 'Produtos diversos de petshops'),
    (NULL, 'Construção', 'Materiais de construção para pequenas residências'),
    (NULL, 'Salgadinhos', 'Salgadinhos empacotados'),
    (NULL, 'Camisas', 'Camisas de diversos formatos e texturas'),
	(NULL, 'Teclados digitais', 'Teclado digitais de baixo custo');

INSERT INTO PRODUTO VALUES
	(NULL, 71352673000159, 2, 'Cimento Todas as Obras 50kg', 19.00, 'Cimento composto com escória granulada de alto forno', 'ativo', 1, 0.02, 17000.00),
	(NULL, 97164264000112, 1, 'Ração pedigree 20kg', 165.00, 'Ração para cachorros de pequeno porte', 'ativo', 1, 0.01, 15000.00),
    (NULL, 75190619000105, 5, 'Teclado Yamaha 150cc', 600.00, 'Teclado com teclas retroiluminadas', 'inativo', 1, 0.03, 150000.00),
	(NULL, 53448711000190, 4, 'Camisa do naruto GG', 20.00, 'Camisa de tamanho GG com estampa do naruto', 'ativo', 1, 0.04, NULL),
    (NULL, 14735279000166, 1, 'Osso DogMania 200g', 4.00, 'Osso alimentício para cachorros de grande porte', 'ativo', 5, 0.03, 5000.00);

INSERT INTO contem VALUES
	(1, 1, 50, 160.00),
    (2, 2, 30, 19.00),
    (3, 3, 180, 4.00),
    (4, 4, 200, 20.00),
    (5, 5, 30, 570.00);

INSERT INTO estoca VALUES
	(81413102000130, 1, 50, 300, '2019-02-19 12:30:31'),
    (51376107000170, 2, 100, 500, '2019-01-20 16:31:53'),
    (53354797000191, 3, 1300, 1800, '2019-03-29 10:30:01'),
    (46108561000100, 4, 20, 30, '2019-04-10 12:00:10'),
    (28193727000151, 5, 5, 25, '2019-05-05 15:50:55');

INSERT INTO PAGAMENTO VALUES
    (NULL, '2018-03-18', 1200.00, 'D', 'Pagamento referente ao mês de março de 2018', 84489381000, '2018-02-18'),
    (NULL, '2018-04-18', 1200.00, 'D', 'Pagamento referente ao mês de abril de 2018', 84489381000, '2018-02-18'),
    (NULL, '2018-04-22', 1000.00, 'T', 'Pagamento referente ao mês de abril de 2016', 30978251008, '2016-03-22'),
    (NULL, '2018-05-22', 1000.00, 'T', 'Pagamento referente ao mês de maio de 2016', 30978251008, '2016-03-22'),
    (NULL, '2018-10-03', 1200.00, 'D', 'Pagamento referente ao mês de outubro de 2014', 12709034034, '2014-09-03');
