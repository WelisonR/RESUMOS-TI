-- --------     << TF1 >>     ------------
-- 
--                    SCRIPT DE POPULA (DML)
-- 
-- Data Criacao ...........: 02/07/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis, 17/0024121
-- ........................: Rafael Makaha Gomes Ferreira, 16/0142369
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: TF1_Final_por_Dupla
-- 
-- Data Ultima Alteracao ..: 02/07/2019
--   => Criacao do script de popula
-- 
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
-- 
-- -----------------------------------------------------------------

USE TF1_Final_por_Dupla;

INSERT INTO EMPRESA VALUES
	(21028310000194, 1012312101, 'Luis Representante',  'luisrepresenta@gmail.com', 1, 'Setor Autárquico', 32440503, 'Rua Tiradentes', 'DF', 'Casa', 'Gama'),
	(97164264000112, 1032124012, 'PetShop Maria',  'petshopmaria@gmail.com', 33, 'Setor Norte', 72400000, 'Itamaracá', 'DF', 'Casa', 'Gama'),
	(14735279000166, 1035912901, 'Casa dos bichos', 'pethousek@email.com', 14, 'QNQ', 71100003, 'Rua Sete de Setembro', 'DF', '´lote 14, próximo a empresa AMBEV', 'Taguatinga'),
    (71352673000159, 1042141912, 'Home Center', 'homecenter@email.com', 24, 'SIA', 71100004, 'trecho 4', 'DF', 'lote 24, próximo a BR-040', 'SIA' ),
    (81413102000130, 1051241123, 'Demacol', 'demacol@email.com', 1, 'QNS', 71100001, 'rua 2', 'DF', 'lote 1, próximo ao supercei', 'Ceilândia' ),
    (28193727000151, 1089123123, 'Seda', 'seda@email.com', 11, 'Setor Sul', 71100004, 'rua Carlos Magno', 'DF', 'lote 11, próximo a UnB-Gama', 'Gama' ),
    (53354797000191, 1090121231, 'Elma Chips', 'elmachipsinha@email.com', 1, 'Setor Norte', 36001300, 'Avenida Brasil', 'DF', 'Loteamento 1, próximo a BR 020', 'Taguatinga');

INSERT INTO telefone VALUES
	(21028310000194, 55061984362231),
	(21028310000194, 55061995392231),
	(97164264000112, 55061995361221),
	(97164264000112, 55061985363231),
	(14735279000166, 55061985368261),
	(71352673000159, 55061995361281),
	(81413102000130, 05506132361271),
	(28193727000151, 05506131381731),
	(28193727000151, 05506139261231),
    (53354797000191, 55061938140989);

-- TUPLA ÚNICA, POIS REPRESENTA APENAS O LUÍS
INSERT INTO REPRESENTANTE VALUES
	(21028310000194, 3877652);

INSERT INTO FUNCIONARIO VALUES
	(84489381000, '2018-02-18', 21028310000194, 'João Alvés da Silva Damasceno', 'JOAOJM', '2000-03-23', 55061996781876, 1200.00, 33, 'Setor Sul', 67000123, 'Rua Buruti', 'DF', 'Casa', 'Gama', NULL),
    (30978251008, '2016-03-22', 21028310000194, 'Maria da Silvinha Sousa', 'MARYMM', '1998-06-13', 55061985612100, 1200.00, 19, 'Setor Oeste', 73005200, 'Rua Itamaracá', 'DF', 'Casa', 'Gama', '2018-01-19'),
    (12709034034, '2014-09-03', 21028310000194, 'Lúcio Costa Pereira', 'LUCINHO', '1996-03-30', 55061967871232, 1200.00, 03, 'Setor X', 34001321, 'Rua Matos Brasil', 'DF', 'Apartamento', 'Gama', '2016-02-15');

-- CNPJs 97164264000112, 14735279000166 e 71352673000159 são fornecedores
INSERT INTO FORNECEDOR VALUES
	(97164264000112, 21028310000194, '2017-09-13', 'ativo'),
    (14735279000166, 21028310000194, '2019-06-19', 'ativo'),
    (71352673000159, 21028310000194, '2011-12-30', 'ativo');

INSERT INTO regiaoRepresentada VALUES
	(97164264000112, 'Gama'),
    (97164264000112, 'Valparaiso'),
    (14735279000166, 'Samambaia'),
    (71352673000159, 'Taguatinga');

-- CNPJs 81413102000130, 28193727000151 e 53354797000191 são clientes
INSERT INTO CLIENTE VALUES
	(81413102000130, '2017-03-19', 'ativo'),
    (28193727000151, '2000-12-29', 'ativo'),
    (53354797000191, '2012-05-12', 'ativo');

INSERT INTO limita VALUES
	(81413102000130, 97164264000112, 135000.00),
    (28193727000151, 14735279000166, 190300.00),
    (53354797000191, 71352673000159, 35000.00);

INSERT INTO RELATORIO VALUES
	(NULL, 21028310000194, 81413102000130, '2019-02-19', 'Necessidade de reposição se mantém constante. A nova administração da loja está com bom desempenho', '2019-03-19'),
    (NULL, 21028310000194, 81413102000130, '2019-01-19', 'Vendas estão constantes e consistentes. Continuar verificação mensal das necessidades do cliente', '2019-02-19'),
    (NULL, 21028310000194, 28193727000151, '2019-02-20', 'Poucas vendas dos produtos fornecidos. Foi orientado como melhor dispor os produtos. Verificar novamente o desempenho do cliente em um período de tempo menor', '2019-03-05'),
    (NULL, 21028310000194, 53354797000191, '2019-02-25', 'Bom desempenho de venda. A demanda por produtos continua com a mesma consistência', '2019-02-13');

INSERT INTO PEDIDO VALUES
	(NULL, 1, '2019-03-15', '2019-03-22', NULL, NULL, 'pendente'),
    (NULL, 2, '2019-01-10', '2019-01-30', '2019-02-23', '2019-02-27', 'entregue'),
    (NULL, 3, '2018-11-14', '2018-11-20', '2019-12-14', '2018-12-14', 'entregue');

INSERT INTO CATEGORIA VALUES
	(NULL, 'PetShop', 'Produtos diversos de petshops'),
    (NULL, 'Construção', 'Materiais de construção para pequenas residências'),
    (NULL, 'Salgadinhos', 'Salgadinhos empacotados');

INSERT INTO PRODUTO VALUES
	(NULL, 97164264000112, 1, 'Ração pedigree 20kg', 165.00, 'Ração para cachorros de pequeno porte', 'ativo', 1, 0.01, 15000.00),
    (NULL, 71352673000159, 2, 'Cimento Todas as Obras 50kg', 19.00, 'Cimento para estruturas de grande porte', 'ativo', 1, 0.02, 17000.00),
    (NULL, 14735279000166, 1, 'Osso DogMania 200g', 4.00, 'Osso alimentício para cachorros de grande porte', 'ativo', 5, 0.03, 5000.00);

INSERT INTO contem VALUES
	(1, 1, 50, 160.00),
    (2, 2, 30, 19.00),
    (3, 3, 180, 4.00);

INSERT INTO estoca VALUES
	(81413102000130, 1, 50, 300),
    (28193727000151, 2, 100, 500),
    (53354797000191, 3, 1300, 1800);
