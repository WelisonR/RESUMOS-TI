-- --------     << TF1 >>     ------------
-- 
--                    SCRIPT DE APAGA (DDL)
-- 
-- Data Criacao ...........: 02/07/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis, 17/0024121
-- ........................: Rafael Makaha Gomes Ferreira, 16/0142369
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: TF1_Final_por_Dupla
-- 
-- Data Ultima Alteracao ..: 02/07/2019
--   => Criacao do script de apagar
-- 
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
-- 
-- -----------------------------------------------------------------

USE TF1_Final_por_Dupla;

DROP TABLE estoca;
DROP TABLE contem;
DROP TABLE PRODUTO;
DROP TABLE CATEGORIA;
DROP TABLE PEDIDO;
DROP TABLE RELATORIO;
DROP TABLE limita;
DROP TABLE CLIENTE;
DROP TABLE regiaoRepresentada;
DROP TABLE FORNECEDOR;
DROP TABLE FUNCIONARIO;
DROP TABLE REPRESENTANTE;
DROP TABLE telefone;
DROP TABLE EMPRESA;
