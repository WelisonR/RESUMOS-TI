-- --------     << EMPRESA FUI - v2 >>     ------------
-- 
--                    SCRIPT DE POPULAR (DML)
-- 
-- Data Criacao ...........: 08/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer7;

INSERT INTO PESSOA(nome, sexo, dtNascimento) VALUES
    ('gabriel batista', 'm', '1998-03-05'),
    ('bart vandor', 'm', '1995-11-11'),
    ('rafael do vale', 'f', '1995-12-11'),
    ('amanda rose', 'f', '1995-11-11'),
    ('bojack horseman', 'm', '1995-11-11'),
    ('ricka morte', 'f', '1987-03-04');

INSERT INTO DEPENDENTE VALUES
    (1, "filho"),
    (2, "pai"),
    (3, "irmão");

INSERT INTO DEPARTAMENTO VALUES
    (1212, 'Comercial'),
    (1432, 'Administrativo'),
    (3213, 'Recursos Humanos');
    
INSERT INTO endereco (rua, numero, bairro, cidade) VALUES
	('Rua do bosque', 3, 'bosque', 'sao paulo'),
	('Avenida Paulista', 1, 'sao paulo', 'sao paulo'),
    ('segunda av.', 1520, 'nucleo bandeir.', 'brasilia');

INSERT INTO EMPREGADO VALUES
    (444, 4, 1, 1212, '1200.00'),
    (424, 5, 2, 1432, '13200.00'),
    (400, 6, 3, 3213, '14600.00');

INSERT INTO LOCAL(descricaoLocal) VALUES
    ('Loja 3'),
    ('Subsolo do patio'),
    ('Loja do Shopping');

INSERT INTO PROJETO VALUES
    (33, 1, 1432, 'Novo portal'),
    (34, 2, 1212, 'Refatoração do cod.'),
    (75, 3, 3213, 'Prototipação inicial');

-- supervisor e empregado
INSERT INTO supervisiona VALUES
    (444,424),
    (400,444),
    (424,400);

INSERT INTO tem VALUES
    (1212, 1),
    (1432, 2),
    (3213, 3);

INSERT INTO possui VALUES
    (444, 1),
    (424, 2),
    (400, 3);

INSERT INTO trabalha VALUES
    (444, 33, 40),
    (444, 34, 88),
    (424, 75, 8),
    (400, 34, 120);

INSERT INTO gerencia VALUES
    (444, 1212, '2019-03-03'),
    (424, 1432, '2018-06-07'),
    (400, 3213, '2018-11-12');