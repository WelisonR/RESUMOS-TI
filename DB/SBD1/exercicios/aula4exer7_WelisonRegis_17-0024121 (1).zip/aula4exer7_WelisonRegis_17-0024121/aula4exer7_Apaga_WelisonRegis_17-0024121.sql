-- --------     << EMPRESA FUI - v2 >>     ------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 08/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer7;

DROP TABLE gerencia;
DROP TABLE trabalha;
DROP TABLE possui;
DROP TABLE tem;
DROP TABLE supervisiona;
DROP TABLE PROJETO;
DROP TABLE LOCAL;
DROP TABLE EMPREGADO;
DROP TABLE DEPARTAMENTO;
DROP TABLE endereco;
DROP TABLE DEPENDENTE;
DROP TABLE PESSOA;