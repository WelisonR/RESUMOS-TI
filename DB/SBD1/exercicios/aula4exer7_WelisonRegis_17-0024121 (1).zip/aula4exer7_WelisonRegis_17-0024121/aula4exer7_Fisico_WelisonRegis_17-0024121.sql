-- ------------------   << EMPRESA FUI - v2 >>   ------------------
--
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 08/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE database IF NOT EXISTS aula4exer7;

USE aula4exer7;

CREATE TABLE PESSOA (
    idPessoa INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL,
    sexo ENUM('m','f') NOT NULL,
    dtNascimento date NOT NULL,
CONSTRAINT PESSOA_PK PRIMARY KEY (idPessoa)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE DEPENDENTE (
    idPessoa INT NOT NULL,
    ligacao VARCHAR(20) NOT NULL,
CONSTRAINT DEPENDENTE_PK PRIMARY KEY (idPessoa),
CONSTRAINT DEPENDENTE_PESSOA_FK FOREIGN KEY (idPessoa) 
    REFERENCES PESSOA(idPessoa)
)ENGINE = InnoDB;

CREATE TABLE DEPARTAMENTO (
    numeroDepartamento INT NOT NULL,
    nomeDepartamento VARCHAR(50) NOT NULL,
CONSTRAINT DEPARTAMENTO_PK PRIMARY KEY (numeroDepartamento)
)ENGINE = InnoDB;

CREATE TABLE endereco (
    idEndereco INT NOT NULL AUTO_INCREMENT,
    rua VARCHAR(50) NOT NULL,
    numero INT(5) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
CONSTRAINT endereco_PK PRIMARY KEY (idEndereco)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE EMPREGADO (
    matriculaEmpregado INT NOT NULL,
    idPessoa INT NOT NULL UNIQUE,
    idEndereco INT NOT NULL,
    numeroDepartamento INT NOT NULL,
    salario DECIMAL(8, 2) NOT NULL,
CONSTRAINT EMPREGADO_PK PRIMARY KEY (matriculaEmpregado),
CONSTRAINT EMPREGADO_PESSOA_FK FOREIGN KEY (idPessoa) 
    REFERENCES PESSOA(idPessoa),
CONSTRAINT EMPREGADO_endereco_FK FOREIGN KEY (idEndereco)
    REFERENCES endereco (idEndereco),
CONSTRAINT EMPREGADO_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento) 
    REFERENCES DEPARTAMENTO(numeroDepartamento)
)ENGINE = InnoDB;

CREATE TABLE LOCAL (
    idLocal INT NOT NULL AUTO_INCREMENT,
    descricaoLocal VARCHAR(50) NOT NULL,
CONSTRAINT LOCAL_PK PRIMARY KEY (idLocal)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PROJETO (
    numeroProjeto INT NOT NULL,
    idLocal INT NOT NULL,
    numeroDepartamento INT NOT NULL,
    nomeProjeto VARCHAR(30) NOT NULL,
CONSTRAINT PROJETO_PK PRIMARY KEY (numeroProjeto),
CONSTRAINT PROJETO_LOCAL_FK FOREIGN KEY (idLocal) 
    REFERENCES LOCAL(idLocal),
CONSTRAINT PROJETO_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento) 
    REFERENCES DEPARTAMENTO(numeroDepartamento)
)ENGINE = InnoDB;

CREATE TABLE tem (
    numeroDepartamento INT NOT NULL,
    idLocal INT NOT NULL,
CONSTRAINT tem_PK PRIMARY KEY (numeroDepartamento, idLocal),
CONSTRAINT tem_DEPARTAMENTO_FK FOREIGN KEY(numeroDepartamento) 
    REFERENCES DEPARTAMENTO(numeroDepartamento),
CONSTRAINT tem_LOCAL_FK FOREIGN KEY (idLocal) 
    REFERENCES LOCAL(idLocal)
)ENGINE = InnoDB;

CREATE TABLE supervisiona (
    matriculaSupervisor INT NOT NULL,
    matriculaEmpregado INT NOT NULL,
CONSTRAINT supervisona_PK PRIMARY KEY (matriculaEmpregado),
CONSTRAINT supervisionado_EMPREGADO_PK FOREIGN KEY (matriculaEmpregado)
    REFERENCES EMPREGADO(matriculaEmpregado),
CONSTRAINT supervisor_EMPREGADO_PK FOREIGN KEY (matriculaSupervisor)
    REFERENCES EMPREGADO(matriculaEmpregado)
)ENGINE = InnoDB;

CREATE TABLE trabalha (
    matriculaEmpregado INT NOT NULL,
    numeroProjeto INT NOT NULL,
    horasTrabalhadas INT NOT NULL,
CONSTRAINT trabalha_PK PRIMARY KEY (matriculaEmpregado, numeroProjeto),
CONSTRAINT trabalha_EMPREGADO_FK FOREIGN KEY (matriculaEmpregado) 
    REFERENCES EMPREGADO (matriculaEmpregado),
CONSTRAINT trabalha_PROJETO_FK FOREIGN KEY (numeroProjeto) 
    REFERENCES PROJETO(numeroProjeto)
)ENGINE = InnoDB;

CREATE TABLE possui (
    matriculaEmpregado INT NOT NULL,
    idPessoa INT NOT NULL,
CONSTRAINT possui_PK PRIMARY KEY (matriculaEmpregado, idPessoa),
CONSTRAINT possui_EMPREGADO_FK FOREIGN KEY (matriculaEmpregado)
    REFERENCES EMPREGADO(matriculaEmpregado),
CONSTRAINT possui_DEPENDENTE_FK FOREIGN KEY (idPessoa)
    REFERENCES DEPENDENTE (idPessoa)
)ENGINE = InnoDB;

CREATE TABLE gerencia (
    matriculaEmpregado INT NOT NULL,
    numeroDepartamento INT NOT NULL,
    dtInicio DATE NOT NULL,
CONSTRAINT gerencia_PK PRIMARY KEY (matriculaEmpregado, numeroDepartamento),
CONSTRAINT gerencia_EMPREGADO_FK FOREIGN KEY (matriculaEmpregado) 
    REFERENCES EMPREGADO(matriculaEmpregado),
CONSTRAINT gerencia_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento) 
    REFERENCES DEPARTAMENTO(numeroDepartamento)
)ENGINE = InnoDB;
