-- --------     << EMPRESA FUI >>     ------------
-- 
--                    SCRIPT DE POPULAR (DML)
-- 
-- Data Criacao ...........: 04/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 04/06/2019
--   => Criacao do script de popular
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer7;

INSERT INTO endereco VALUES
(NULL, 33, 'Itamaraca', 'Setor Norte', 'Gama', 72440800, 'DF'),
(NULL, 13, 'Testelavi', 'Setor sul', 'Samambaia', 72440102, 'GO'),
(NULL, 10, 'Santos Dummond', 'Setor Oeste', 'Ceilândia', 36400302, 'GO');

INSERT INTO DEPARTAMENTO VALUES
(1, 'Ciência de dados', '2000-02-12', 1),
(2, 'Engenharia de requisitos', '2002-02-19', 2),
(3, 'Suporte técnico', '2005-06-22', 3);

INSERT INTO localizacao VALUES
(1, 'Zona Norte, A8'),
(2, 'Zona Sul, A9'),
(3, 'Zona Central, A1');

INSERT INTO EMPREGADO VALUES
(1, 1, 1, 'João Ataiudes Ribeiro', '12.000', 'M', '1979-02-19', NULL),
(2, 3, 3, 'Aristóteles da Silva Junior', '3.020', 'M', '1999-02-19', 1),
(3, 2, 2, 'Maria da Silva Rosângela Vieira', '13.200', 'F', '1978-02-20', 1);

INSERT INTO PROJETO VALUES
(1, 3, 'Redes de comunicações interna', 'A1, sala 33'),
(2, 2, 'Engenharia de Requisitos na organização', 'A9, sala 12'),
(3, 1, 'Redes neurais para predição de preferências', 'A8, sala 11');

INSERT INTO trabalha VALUES
(1, 1, 30),
(2, 3, 10),
(3, 1, 20),
(2, 2, 30);

INSERT INTO DEPENDENTE VALUES
(NULL, 'Filho', '2000-02-14', 'M', 'Miguel Lucas da Silva'),
(NULL, 'Esposa', '2003-05-20', 'F', 'Joana do Carmo dos Testes'),
(NULL, 'Filha', '2005-07-12', 'F', 'Julia da Silva Sousa');

INSERT INTO possui VALUES
(1, 1),
(2, 2),
(3, 3);