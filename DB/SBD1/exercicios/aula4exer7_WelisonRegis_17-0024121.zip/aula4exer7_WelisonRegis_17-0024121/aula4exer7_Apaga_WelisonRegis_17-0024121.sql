-- --------     << EMPRESA FUI >>     ------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 04/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 04/06/2019
--   => Criacao do script de apagar
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer7;

DROP TABLE possui;
DROP TABLE DEPENDENTE;
DROP TABLE trabalha;
DROP TABLE PROJETO;
DROP TABLE EMPREGADO;
DROP TABLE endereco;
DROP TABLE localizacao;
DROP TABLE DEPARTAMENTO;
