-- --------     << EMPRESA FUI >>     ------------
-- 
--                    SCRIPT DE CONTROLE
-- 
-- Data Criacao ...........: 04/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 04/06/2019
--   => Criacao de usario usufui com permissões DML
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer7;

CREATE USER 'usufui'
	IDENTIFIED BY 'fui123';
GRANT SELECT, INSERT, UPDATE, DELETE ON aula4exer7.* TO usufui;