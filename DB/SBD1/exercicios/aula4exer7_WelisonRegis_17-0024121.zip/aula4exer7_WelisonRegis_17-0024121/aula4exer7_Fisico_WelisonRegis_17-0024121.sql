-- --------     << EMPRESA FUI >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 04/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 04/06/2019
--   => Criacao do script de criacao
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer7;

USE aula4exer7;

CREATE TABLE endereco (
    idEndereco BIGINT NOT NULL AUTO_INCREMENT,
    numero INT(5) NOT NULL,
    rua VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    cep INT(8) NOT NULL,
    uf VARCHAR(2) NOT NULL,
CONSTRAINT endereco_PK PRIMARY KEY (idEndereco)
) AUTO_INCREMENT = 1 ENGINE = InnoDB;

CREATE TABLE DEPARTAMENTO (
    numeroDepartamento BIGINT NOT NULL,
    nomeDepartamento VARCHAR(50) NOT NULL,
    dtInicio DATE,
    matricula BIGINT,
CONSTRAINT DEPARTAMENTO_PK PRIMARY KEY (numeroDepartamento)
) ENGINE = InnoDB;

CREATE TABLE localizacao (
    numeroDepartamento BIGINT NOT NULL,
    localizacao VARCHAR(100) NOT NULL,
CONSTRAINT localizacao_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento)
REFERENCES DEPARTAMENTO (numeroDepartamento)
) ENGINE = InnoDB;

CREATE TABLE EMPREGADO (
    matricula BIGINT NOT NULL,
    idEndereco BIGINT NOT NULL,
    numeroDepartamento BIGINT NOT NULL,
    nomeEmpregado VARCHAR(50) NOT NULL,
    salario DECIMAL(8,2) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    dtNascimento DATE NOT NULL,
	matriculaSupervisor BIGINT,
CONSTRAINT EMPREGADO_PK PRIMARY KEY (matricula),
CONSTRAINT EMPREGADO_endereco_FK FOREIGN KEY (idEndereco)
REFERENCES endereco (idEndereco),
CONSTRAINT EMPREGADO_EMPREGADO_FK FOREIGN KEY (matriculaSupervisor)
REFERENCES EMPREGADO (matricula),
CONSTRAINT EMPREGADO_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento)
REFERENCES DEPARTAMENTO (numeroDepartamento)
) ENGINE = InnoDB;

CREATE TABLE PROJETO (
    numeroProjeto BIGINT NOT NULL,
    numeroDepartamento BIGINT NOT NULL,
    nomeProjeto VARCHAR(50) NOT NULL,
    localizacao VARCHAR(100) NOT NULL,
CONSTRAINT PROJETO_PK PRIMARY KEY (numeroProjeto),
CONSTRAINT PROJETO_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento)
REFERENCES DEPARTAMENTO (numeroDepartamento)
) ENGINE = InnoDB;

CREATE TABLE trabalha (
    numeroProjeto BIGINT NOT NULL,
    matricula BIGINT NOT NULL,
    hora INT NOT NULL,
CONSTRAINT trabalha_PK PRIMARY KEY (numeroProjeto, matricula),
CONSTRAINT trabalha_PROJETO_FK FOREIGN KEY (numeroProjeto)
REFERENCES PROJETO (numeroProjeto),
CONSTRAINT trabalha_EMPREGADO_FK FOREIGN KEY (matricula)
REFERENCES EMPREGADO (matricula)
) ENGINE = InnoDB;

CREATE TABLE DEPENDENTE (
    idDependente BIGINT NOT NULL AUTO_INCREMENT,
    parentesco VARCHAR(35) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    nomeDependente VARCHAR(50) NOT NULL,
CONSTRAINT DEPENDENTE_PK PRIMARY KEY (idDependente)
) AUTO_INCREMENT = 1 ENGINE = InnoDB;

CREATE TABLE possui (
    matricula BIGINT NOT NULL,
    idDependente BIGINT NOT NULL,
CONSTRAINT possui_PK PRIMARY KEY (matricula, idDependente),
CONSTRAINT possui_EMPREGADO_FK FOREIGN KEY (matricula)
REFERENCES EMPREGADO (matricula),
CONSTRAINT possui_DEPENDENTE_FK FOREIGN KEY (idDependente)
REFERENCES DEPENDENTE (idDependente)
) ENGINE = InnoDB;