from operator import attrgetter

class Motorista:
    def __init__(self, id, first_name, last_name, RG):
        self.id = int(id)
        self.first_name = first_name
        self.last_name = last_name
        self.RG = RG

    
class Veiculo:
    def __init__(self, id_motorista, renavam):
        self.id_motorista = int(id_motorista)
        self.renavam = renavam


def ler_motoristas():
    motoristas = []
    k = 0
    with open('motoristas.txt', 'r') as f:
        for line in f:
            if k == 0:
                k = -1
                continue
            
            id = line.split()[0].strip(" ")
            first_name = line.split()[1].strip(" ")
            last_name = line.split()[2].strip(" ")
            RG = line.split()[3].strip(" ")

            motoristas.append(Motorista(id, first_name, last_name, RG))
    
    return motoristas

def ler_veiculos():
    veiculos = []
    k = 0
    with open('veiculos.txt', 'r') as f:
        for line in f:
            if k == 0:
                k = -1
                continue
            
            id_motorista = line.split()[0].strip(" ")
            renavam = line.split()[1].strip(" ")

            veiculos.append(Veiculo(id_motorista, renavam))
  
    return veiculos

def lista_veiculos_donos(motoristas, veiculos):
    print("{:<20}{:<20}{:<20}{:<20}".format("NOME", "SOBRENOME", "RG", "RENAVAM"))
    for veiculo in veiculos:
        id_motorista = int(veiculo.id_motorista)
        first_name = motoristas[id_motorista-1].first_name
        last_name = motoristas[id_motorista-1].last_name
        RG = motoristas[id_motorista-1].RG

        print("{:<20}{:<20}{:<20}{:<20}".format(first_name, last_name, RG, veiculo.renavam))

def deleta_veiculo(veiculos, renavam):
    item = -1
    for i, veiculo in enumerate(veiculos):
        if veiculo.renavam == renavam:
            item = i
            break
    
    if (item == -1):
        print("\n\n\nNão consta em nossos registros esse RENAVAM!\n\n\n")
    else:
        del veiculos[item]
        print("\n\n\nVeículo excluído!\n\n\n")

    return veiculos

def novo_veiculo(motoristas, veiculos):
    print('\n\n\n')
    print("Digite o seu primeiro nome: ", end='')
    first_name = input()
    print("Digite o seu último nome: ", end='')
    last_name = input()
    print("Digite o seu RG (7 digitos, sem pontuações): ", end='')
    RG = input()
    print("Digite o renavam do carro (11 digitos, sem pontuações): ", end='')
    renavam = input()

    if " " in first_name or " " in last_name:
        print("\n\n\nDigite os campos nome e último nome corretamente!\n\n\n")
        return motoristas, veiculos
    
    if len(RG) != 7 or not RG.isdigit():
        print("\n\n\nRG inválido!\n\n\n")
        return motoristas, veiculos

    if len(renavam) != 11 or not renavam.isdigit():
        print("\n\n\nDigite um renavam válido!\n\n\n")
    
    for veiculo in veiculos:
        if veiculo.renavam == renavam:
            print("\n\n\nRenavam já cadastrado!\n\n\n")
            return motoristas, veiculos

    id_max = len(motoristas)
    for motorista in motoristas:
        if motorista.RG == RG:
            id_motorista = int(motorista.id)
            veiculo = Veiculo(id_motorista, renavam)
            veiculos.append(veiculo)

            print("\n\n\nVeículo incluido aos registros!\n\n\n")
            return motoristas, veiculos
    else: 
        motorista = Motorista(id_max+1, first_name, last_name, RG)
        veiculo = Veiculo(id_max+1, renavam)

        print("\n\n\nVeículo e motorista incluidos aos registros!\n\n\n")
        motoristas.append(motorista)
        veiculos.append(veiculo)


    return motoristas, veiculos


def write_motoristas(motoristas):
    file = open("motoristas.txt","w") 
 
    file.write("{:<20}{:<20}{:<20}{:<20}\n".format("ID", "FIRST_NAME", "LAST_NAME", "RG"))
    
    for motorista in motoristas:
        file.write("{:<20}{:<20}{:<20}{:<20}\n".format(motorista.id, motorista.first_name, motorista.last_name, motorista.RG))

    file.close() 

def write_veiculos(veiculos):
    file2 = open("veiculos.txt", "w")

    file2.write("{:<20}{:<20}\n".format("ID_MOTORISTA", "RENAVAM"))

    for veiculo in veiculos:
        file2.write("{:<20}{:<20}\n".format(veiculo.id_motorista, veiculo.renavam))
    
    file2.close()

def show_options():
    print("\nPor favor, selecione uma dentre as opções abaixo:\n")
    print("1- Listar RENAVAMs com seus proprietários\n")
    print("2- Cadastrar novo veículo\n")
    print("3- Excluir veículo\n")
    print("0- Encerrar e salvar!\n")
    print(">>> : ", end='')

if __name__ == "__main__":
    motoristas = ler_motoristas()
    veiculos = ler_veiculos()

    while(True):
        show_options()
        opt = int(input())

        if opt == 0:
            print("\n\n\nBancos 'motoristas.txt' e 'veiculo.txt' atualizados!\n\n\n")
            lista_veiculos_donos(motoristas, veiculos)
            break
        if opt == 1:
            lista_veiculos_donos(motoristas, veiculos)
        if opt == 2:
            motoristas, veiculos = novo_veiculo(motoristas, veiculos)
        if opt == 3:
            print("\n\n\nPor favor, digite o RENAVAM (11 digitos, sem pontuações):")
            print(">>> :", end='')
            renavam = input()
            veiculos = deleta_veiculo(veiculos, renavam)
    
    motoristas.sort(key = attrgetter('id'), reverse = False)
    veiculos.sort(key = attrgetter('id_motorista'), reverse = False)

    write_motoristas(motoristas)
    write_veiculos(veiculos)