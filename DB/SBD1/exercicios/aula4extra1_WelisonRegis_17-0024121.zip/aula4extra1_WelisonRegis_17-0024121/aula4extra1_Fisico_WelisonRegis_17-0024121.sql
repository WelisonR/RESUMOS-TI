-- --------     << DISCIPLINAS >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 07/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4extra1
-- 
-- Data Ultima Alteracao ..: 07/06/2019
--   => Criacao do script de criacao
-- 
-- PROJETO => 01 Base de Dados
--         => 06 tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4extra1;

USE aula4extra1;


CREATE TABLE AREA_CONHECIMENTO (
    codArea INT(8) NOT NULL,
    nomeArea VARCHAR(50) NOT NULL,
CONSTRAINT AREA_CONHECIMENTO_PK PRIMARY KEY (codArea)
) ENGINE = InnoDB;

CREATE TABLE DEPARTAMENTO (
    codDepartamento INT NOT NULL,
    codArea INT(8) NOT NULL,
    nomeDepartamento VARCHAR(50) NOT NULL,
CONSTRAINT DEPARTAMENTO_PK PRIMARY KEY (codDepartamento),
CONSTRAINT DEPARTAMENTO_AREA_CONHECIMENTO_FK FOREIGN KEY (codArea)
REFERENCES AREA_CONHECIMENTO (codArea)
) ENGINE = InnoDB;

CREATE TABLE CURSO (
    codCurso INT(4) NOT NULL,
    codDepartamento INT NOT NULL,
    codArea INT(8) NOT NULL,
    nomeCurso VARCHAR(50) NOT NULL,
    creditoTotal INT(3) NOT NULL,
CONSTRAINT CURSO_PK PRIMARY KEY (codCurso),
CONSTRAINT CURSO_DEPARTAMENTO_FK FOREIGN KEY (codDepartamento)
REFERENCES DEPARTAMENTO (codDepartamento),
CONSTRAINT CURSO_AREA_CONHECIMENTO_FK FOREIGN KEY (codArea)
REFERENCES AREA_CONHECIMENTO (codArea)
) ENGINE = InnoDB;

CREATE TABLE DISCIPLINA (
    codDisciplina INT(8) NOT NULL,
    codDepartamento INT NOT NULL,
    nomeDisciplina VARCHAR(50) NOT NULL,
    credito INT(2) NOT NULL,
CONSTRAINT DISCIPLINA_PK PRIMARY KEY (codDisciplina),
CONSTRAINT DISCIPLINA_DEPARTAMENTO_FK FOREIGN KEY (codDepartamento)
REFERENCES DEPARTAMENTO (codDepartamento)
) ENGINE = InnoDB;

CREATE TABLE tem (
    codCurso INT(4) NOT NULL,
    codDisciplina INT(8) NOT NULL,
CONSTRAINT tem_PK PRIMARY KEY (codCurso, codDisciplina),
CONSTRAINT tem_CURSO_FK FOREIGN KEY (codCurso)
REFERENCES CURSO (codCurso),
CONSTRAINT tem_DISCIPLINA_FK FOREIGN KEY (codDisciplina)
REFERENCES DISCIPLINA (codDisciplina)
) ENGINE = InnoDB;

CREATE TABLE requer (
    codDisciplina INT(8) NOT NULL,
    codPreRequisito INT(8) NOT NULL,
CONSTRAINT requer_PK PRIMARY KEY (codDisciplina, codPreRequisito),
CONSTRAINT requer_DISCIPLINA_FK_1 FOREIGN KEY (codDisciplina)
REFERENCES DISCIPLINA (codDisciplina),
CONSTRAINT requer_DISCIPLINA_FK_2 FOREIGN KEY (codPreRequisito)
REFERENCES DISCIPLINA (codDisciplina)
) ENGINE = InnoDB;
