-- --------     << DISCIPLINAS >>     ------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 07/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4extra1
-- 
-- Data Ultima Alteracao ..: 08/06/2019
--   => Criacao do script de apagar
-- 
-- PROJETO => 01 Base de Dados
--         => 06 tabelas
-- 
-- -----------------------------------------------------------------

USE aula4extra1;

DROP TABLE requer;
DROP TABLE tem;
DROP TABLE DISCIPLINA;
DROP TABLE CURSO;
DROP TABLE DEPARTAMENTO;
DROP TABLE AREA_CONHECIMENTO;