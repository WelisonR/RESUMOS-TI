-- --------     << DISCIPLINAS >>     ------------
-- 
--                    SCRIPT DE POPULAR (DML)
-- 
-- Data Criacao ...........: 07/06/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4extra1
-- 
-- Data Ultima Alteracao ..: 07/06/2019
--   => Criacao do script de popular
-- 
-- PROJETO => 01 Base de Dados
--         => 06 tabelas
-- 
-- -----------------------------------------------------------------

USE aula4extra1;

-- Códigos em acordo com a classificação do CAPES
INSERT INTO AREA_CONHECIMENTO VALUES
(10000003, 'Ciências Exatas e da Terra'), --
(10100008, 'Matemática'),
(10300007, 'Ciência da Computação'),
(30000009, 'Engenharias'), --
(30100003, 'Engenharia Civil'),
(30200008, 'Engenharia de Minas'),
(50000001, 'Ciências agrárias'), --
(50100009, 'Recursos Florestais e Engenharia Florestal'),
(50300008, 'Engenharia Agrícola');

INSERT INTO DEPARTAMENTO VALUES
(1, 10000003, 'Departamento de Matemática'),
(2, 30000009, 'Departamento de Engenharias'),
(3, 50000001, 'Departamento de Ciências agrárias');

INSERT INTO CURSO VALUES
(752, 1, 10100008, 'Matemática', 198),
(582, 2, 30100003, 'Engenharia Civil', 220),
(396, 3, 50100009, 'Agronomia', 264);

INSERT INTO DISCIPLINA VALUES
(50101005, 3, 'Ciência do Solo', 4),
(50102001, 3, 'Fitossanidade', 6),
(50106007, 3, 'Extensão Rural', 2),
(30101000, 2, 'Construção civil', 4),
(30102006, 2, 'Estruturas', 6),
(30104009, 2, 'Engenharia Hidráulica', 2),
(10100004, 1, 'Álgebra', 4),
(10102000, 1, 'Análise', 6),
(10104003, 1, 'Matemática aplicada', 6);

INSERT INTO tem VALUES
(752, 10100004),
(752, 10102000),
(752, 10104003),
(582, 30101000),
(582, 30102006),
(582, 30104009),
(396, 50101005),
(396, 50102001),
(396, 50106007);

INSERT INTO requer VALUES
(10102000, 10100004),
(30102006, 30101000),
(50102001, 50101005);