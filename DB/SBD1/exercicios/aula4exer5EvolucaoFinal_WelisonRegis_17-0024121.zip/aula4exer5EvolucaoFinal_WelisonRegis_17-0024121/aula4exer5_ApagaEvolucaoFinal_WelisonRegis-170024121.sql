-- -----------     << RECEITUÁRIO - Versão Final >>     -------------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 02/05/2019
-- Autor(es) ..............: Welison Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer5Evolucao4
-- 
-- Data Ultima Alteracao ..: 07/05/2019
--   => Criação do script para apagar os dados do banco
--   => Adiciona condicional nos "drops" de tabelas
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------


USE aula4exer5EvolucaoFinal;

DROP TABLE IF EXISTS contem;
DROP TABLE IF EXISTS MEDICAMENTO;
DROP TABLE IF EXISTS RECEITA;
DROP TABLE IF EXISTS CONSULTA;
DROP TABLE IF EXISTS telefone;
DROP TABLE IF EXISTS PACIENTE;
DROP TABLE IF EXISTS possui;
DROP TABLE IF EXISTS ESPECIALIDADE;
DROP TABLE IF EXISTS MEDICO;