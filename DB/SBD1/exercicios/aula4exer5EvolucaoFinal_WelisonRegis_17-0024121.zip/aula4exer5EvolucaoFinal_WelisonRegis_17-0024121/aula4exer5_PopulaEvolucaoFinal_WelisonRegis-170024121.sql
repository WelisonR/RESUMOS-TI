-- -----------     << RECEITUÁRIO - Versão Final >>     -------------------
-- 
--                    SCRIPT DE POPULAR (DDL)
-- 
-- Data Criacao ...........: 02/05/2019
-- Autor(es) ..............: Welison Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer5Evolucao4
-- 
-- Data Ultima Alteracao ..: 07/05/2019
--   => Criação do script para popular os dados do banco
--   => Evolução final do script de popular o banco
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer5EvolucaoFinal;



-- --------
-- POPULA 1
-- --------
INSERT INTO MEDICO VALUES (
	19837612,
    'Maria Joana da Silva Oliveira'
);

INSERT INTO ESPECIALIDADE VALUES (
	1,
    'Cardiologista'
);

INSERT INTO possui VALUES (
	19837612,
    1
);

INSERT INTO PACIENTE VALUES (
	02376937120,
    'Oscar Sobral Reis',
    'M',
    35,
    'DF',
    'Taguatinga',
    'Setor Norte',
    'Avenida Sibipiruna',
    71928720,
    'Casa',
    13
);

INSERT INTO telefone VALUES (
	55061987654321,
    02376937120
);

INSERT INTO CONSULTA VALUES (
	02376937120,
	19837612,
    '2017-08-19 15:10:19'
);

INSERT INTO RECEITA(dataHora, crm, cpf, posologia) VALUES (
	'2017-08-19 15:10:19',
    19837612,
    02376937120,
    'Tomar 35 gotas de dipirona quando sentir dores na cabeça'
);

INSERT INTO MEDICAMENTO VALUES (
	1,
    'Dipirona',
    'gota'
);

INSERT INTO contem VALUES (
	1,
    1
);



-- --------
-- POPULA 2
-- --------
INSERT INTO MEDICO VALUES (
	23012345,
    'João Guilherme Silva Mendes'
);

INSERT INTO ESPECIALIDADE VALUES (
	2,
    'Pneumologista'
);

INSERT INTO possui VALUES (
	23012345,
    2
);

INSERT INTO PACIENTE VALUES (
	08914123133,
    'Maurício Michel Lulia',
    'M',
    43,
    'DF',
    'Ceilândia',
    'Setor Sul',
    'Avenida Presidente Imprudente',
    71840312,
    'Casa',
    51
);

INSERT INTO telefone VALUES (
	55061987654321,
    08914123133
);

INSERT INTO CONSULTA VALUES (
	08914123133,
	23012345,
    '2017-10-06 13:09:23'
);

INSERT INTO RECEITA(dataHora, crm, cpf, posologia) VALUES (
	'2017-10-06 13:09:23',
    23012345,
    08914123133,
    'Tomar 1 comprimido de aspirina no intervalo de 8 horas; fazer uso do xarope de 4 em 4 horas'
);

INSERT INTO MEDICAMENTO VALUES (
	2,
    'Aspirina Microativa',
    'comprimido'
);

INSERT INTO MEDICAMENTO VALUES (
    3,
    'Loratadina Xarope',
    'líquido'
);

INSERT INTO contem VALUES (
	2,
    2
);

INSERT INTO contem VALUES (
    2,
    3
);