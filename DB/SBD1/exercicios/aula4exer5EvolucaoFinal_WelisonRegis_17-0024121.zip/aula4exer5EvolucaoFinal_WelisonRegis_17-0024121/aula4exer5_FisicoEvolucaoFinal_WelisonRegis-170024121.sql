-- ---------------     << RECEITUÁRIO - Versão Final >>     --------------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 22/04/2019
-- Autor(es) ..............: Welison Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer5EvolucaoFinal
-- 
-- Data Ultima Alteracao ..: 07/05/2019
--   => Criacao de nova tabela
--   => Edição de atributos do crm e algumas constraints
--   => Evolução final do script de criação do banco
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer5EvolucaoFinal;

USE aula4exer5EvolucaoFinal;



CREATE TABLE IF NOT EXISTS MEDICO (
   	crm INT(8) ZEROFILL NOT NULL,
    nome VARCHAR(30) NOT NULL,
    
    CONSTRAINT MEDICO_PK PRIMARY KEY (crm)
);

CREATE TABLE IF NOT EXISTS ESPECIALIDADE (
	codEspecialista INT NOT NULL,
    nomeEspecialista VARCHAR(30) NOT NULL,
    
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (codEspecialista)
);

CREATE TABLE IF NOT EXISTS possui (
	crm INT(8) ZEROFILL NOT NULL,
    codEspecialista INT NOT NULL,
    
    CONSTRAINT possui_PK PRIMARY KEY (codEspecialista, crm),
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY (crm)
    REFERENCES MEDICO (crm),
    CONSTRAINT possui_ESPECIALIADADE_FK FOREIGN KEY (codEspecialista)
    REFERENCES ESPECIALIDADE (codEspecialista)
);

CREATE TABLE IF NOT EXISTS PACIENTE (
	cpf BIGINT(11) ZEROFILL NOT NULL,
    nome VARCHAR(30) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    idade INT NOT NULL,
    uf VARCHAR(2) NOT NULL,
    cidade VARCHAR(30) NOT NULL,
    bairro VARCHAR(30) NOT NULL,
    logradouro VARCHAR(30) NOT NULL,
    cep INT(8) ZEROFILL NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    numero INT NOT NULL,
	
	CONSTRAINT PACIENTE_PK PRIMARY KEY (cpf)
);

CREATE TABLE IF NOT EXISTS telefone (
	telefone BIGINT(14) ZEROFILL NOT NULL,
    cpf BIGINT(11) ZEROFILL NOT NULL,
    
    CONSTRAINT telefone_PK PRIMARY KEY (telefone, cpf),
    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (cpf)
    REFERENCES PACIENTE (cpf)
);

CREATE TABLE IF NOT EXISTS CONSULTA (
	cpf BIGINT(11) ZEROFILL NOT NULL,
    crm INT(8) ZEROFILL NOT NULL,
    dataHora TIMESTAMP NOT NULL,
    
    CONSTRAINT CONSULTA_PK PRIMARY KEY (cpf, crm, dataHora),
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (cpf)
    REFERENCES PACIENTE (cpf),
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (crm)
    REFERENCES MEDICO (crm)
);

CREATE TABLE IF NOT EXISTS RECEITA (
	idReceita INT AUTO_INCREMENT NOT NULL,
    dataHora TIMESTAMP NOT NULL,
    crm INT(8) ZEROFILL NOT NULL,
    cpf BIGINT(11) ZEROFILL NOT NULL,
    posologia VARCHAR(250) NOT NULL,
    
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    CONSTRAINT RECEITA_CONSULTA_FK FOREIGN KEY (cpf, crm, dataHora)
    REFERENCES CONSULTA (cpf, crm, dataHora)
);

CREATE TABLE IF NOT EXISTS MEDICAMENTO (
	codMedicamento INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    descricao VARCHAR(50) NOT NULL,
    
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (codMedicamento)
);

CREATE TABLE IF NOT EXISTS contem (
	idReceita INT NOT NULL,
    codMedicamento INT NOT NULL,
    
    CONSTRAINT contem_PK PRIMARY KEY (idReceita, codMedicamento),
    CONSTRAINT contem_RECEITA_FK FOREIGN KEY (idReceita)
    REFERENCES RECEITA (idReceita),
    CONSTRAINT contem_MEDICAMENTO_FK FOREIGN KEY (codMedicamento)
    REFERENCES MEDICAMENTO (codMedicamento)
);
