-- -----------     << DETRAN - INFRAÇÕES >>     -------------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 02/05/2019
-- Autor(es) ..............: Welison Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6EvolucaoFinal
-- 
-- Data Ultima Alteracao ..: 07/05/2019
--   => Criação do script para apagar os dados do banco
--   => Adiciona clausula "if exists" em "drop table"
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer6EvolucaoFinal;


DROP TABLE IF EXISTS INFRACAO;
DROP TABLE IF EXISTS TIPO_INFRACAO;
DROP TABLE IF EXISTS AGENTE;
DROP TABLE IF EXISTS LOCALIZACAO;
DROP TABLE IF EXISTS VEICULO;
DROP TABLE IF EXISTS CATEGORIA;
DROP TABLE IF EXISTS MODELO;
DROP TABLE IF EXISTS telefone;
DROP TABLE IF EXISTS PROPRIETARIO;
