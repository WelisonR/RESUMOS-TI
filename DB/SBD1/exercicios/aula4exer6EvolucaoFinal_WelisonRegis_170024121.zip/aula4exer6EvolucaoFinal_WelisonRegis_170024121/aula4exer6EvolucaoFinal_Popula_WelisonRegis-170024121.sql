-- -----------     << DETRAN - INFRAÇÕES >>     -------------------
-- 
--                    SCRIPT PARA POPULAR (DML)
-- 
-- Data Criacao ...........: 02/05/2019
-- Autor(es) ..............: Welison Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6EvolucaoFinal
-- 
-- Data Ultima Alteracao ..: 07/05/2019
--   => Criação do script para popular o banco
--   => Adaptações no popula após mudança nos tipos de dados
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer6EvolucaoFinal;



-- -------------------
-- POPULA PROPRIETÁRIO
-- -------------------
INSERT INTO PROPRIETARIO VALUES (
	01234567890,
    'Welison Almeida Regis',
    'Itamaracá',
    100,
    'Gama',
    'Setor Leste',
    'DF',
    'Casa',
    72560300,
    'M',
    '1998-12-06'
);

INSERT INTO PROPRIETARIO VALUES (
	12345678901,
    'Mina Rousseff Lulia',
    'Rua 324',
	90,
    'Ceilândia',
    'Setor Norte',
    'DF',
    'Apartamento São Leopoldo',
    72500300,
    'F',
    '1990-12-06'
);

INSERT INTO PROPRIETARIO VALUES (
	23456789012,
    'Lieverton Oliveira Silva',
    'São Juvenal',
	103,
    'Brazlândia',
    'Setor Sul',
    'DF',
    'Casa',
    30440502,
    'M',
    '2000-05-06'
);


-- ---------------
-- POPULA telefone
-- ---------------
INSERT INTO telefone VALUES (
	01234567890,
    '55061999937278'
);

INSERT INTO telefone VALUES (
	12345678901,
    55021985675654
);

INSERT INTO telefone VALUES (
	23456789012,
    55031983410312
);

-- -------------
-- POPULA MODELO
-- -------------
INSERT INTO MODELO VALUES (
	1,
    'GOL G4'
);

INSERT INTO MODELO VALUES (
	2,
    'Chevrolet D-20'
);

INSERT INTO MODELO VALUES (
	3,
    'Yamaha R100'
);



-- ----------------
-- POPULA CATEGORIA
-- ----------------
INSERT INTO CATEGORIA VALUES (
	1,
    'Carro'
);


INSERT INTO CATEGORIA VALUES (
	2,
    'Caminhonete'
);

INSERT INTO CATEGORIA VALUES (
	3,
    'Moto'
);



-- --------------
-- POPULA VEICULO
-- --------------
INSERT INTO VEICULO VALUES (
	'JKD1234',
	'12345678912345678',
    'Branco',
    1,
    1,
	2012,
    01234567890
);

INSERT INTO VEICULO VALUES (
	'JQJ3093',
	'23456789012345678',
    'Preto',
    2,
    2,
	2000,
    12345678901
);

INSERT INTO VEICULO VALUES (
	'JJC1032',
	'34567890123456789',
    'Cinza',
    3,
    3,
	2009,
    23456789012
);



-- ------------------
-- POPULA LOCALIZACAO
-- ------------------
INSERT INTO LOCALIZACAO VALUES (
	'abc123',
    30.192874,
    301.109231,
    60
);


INSERT INTO LOCALIZACAO VALUES (
	'zyx098',
    20.122479,
    102.139232,
    80
);

INSERT INTO LOCALIZACAO VALUES (
	'kwo192',
    54.125417,
    311.649218,
    80
);



-- -------------
-- POPULA AGENTE
-- -------------
INSERT INTO AGENTE VALUES (
	42,
	'João Carlos Machado',
    '2010-04-12'
);

INSERT INTO AGENTE VALUES (
	43,
	'José Matheus Alvares',
    '2014-01-19'
);

INSERT INTO AGENTE VALUES (
	44,
	'Maurício Esteves Solene',
    '2008-03-22'
);



-- --------------------
-- POPULA TIPO_INFRACAO
-- --------------------
INSERT INTO TIPO_INFRACAO VALUES (
	168,
    'Transportar crinaças de forma irregular',
    293.47
);

INSERT INTO TIPO_INFRACAO VALUES (
	171,
    'Jogar água sobre os pedestres ou veículos',
    293.47
);

INSERT INTO TIPO_INFRACAO VALUES (
	180,
    'Ter seu veículo imobilizado na via por falta de combustível',
    130.16
);



-- ---------------
-- POPULA INFRACAO
-- ---------------
INSERT INTO INFRACAO (placa, dataHora, codInfracao, codLocal, velocidadeAferida, matricula)
VALUES (
	'JKD1234',
    '2017-10-16 14:09:38',
    168,
    'abc123',
    90,
    42
);

INSERT INTO INFRACAO (placa, dataHora, codInfracao, codLocal, velocidadeAferida, matricula)
VALUES (
	'JQJ3093',
    '2017-10-16 14:09:38',
    168,
    'zyx098',
    94,
    43
);

INSERT INTO INFRACAO (placa, dataHora, codInfracao, codLocal, velocidadeAferida, matricula)
VALUES (
	'JJC1032',
    '2017-10-16 14:09:38',
    168,
    'kwo192',
    102,
    44
);
