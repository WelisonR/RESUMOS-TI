-- -----------     << DETRAN - INFRAÇÕES >>     -------------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 25/04/2019
-- Autor(es) ..............: Welison Regis, Andre Pinto
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6EvolucaoFinal
-- 
-- Data Ultima Alteracao ..: 07/05/2019
--   => Criacao de nova tabela INFRACAO
--   => Criacao de tabelas e database apenas se não existir ("IF NOT EXISTS")
-- 	 => Mudança no nome da base de dados
--   => Mudança de tipo de dados de alguns atributos
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer6EvolucaoFinal;

USE aula4exer6EvolucaoFinal;

CREATE TABLE IF NOT EXISTS PROPRIETARIO (
    cpf BIGINT(11) ZEROFILL NOT NULL,
    nome VARCHAR(50) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    numero INT NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    uf CHAR(2) NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    cep INT(8) ZEROFILL NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    dtNascimento DATE NOT NULL,
CONSTRAINT PROPRIETARIO_PK PRIMARY KEY (cpf)
);

CREATE TABLE IF NOT EXISTS telefone (
    cpf BIGINT(11) ZEROFILL NOT NULL,
    telefone BIGINT(14) ZEROFILL NOT NULL,
CONSTRAINT telefone_PK PRIMARY KEY (cpf, telefone),
CONSTRAINT telefone_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO (cpf)
);

CREATE TABLE IF NOT EXISTS MODELO (
    codModelo INT(6) NOT NULL,
    nomeModelo VARCHAR(50) NOT NULL,
CONSTRAINT MODELO_PK PRIMARY KEY (codModelo)
);

CREATE TABLE IF NOT EXISTS CATEGORIA (
    codCategoria INT(2) NOT NULL,
    nomeCategoria VARCHAR(50) NOT NULL,
CONSTRAINT CATEGORIA_PK PRIMARY KEY (codCategoria)
);

CREATE TABLE IF NOT EXISTS VEICULO (
    placa VARCHAR(7) NOT NULL,
    numeroChassi VARCHAR(17) NOT NULL UNIQUE,
    cor VARCHAR(20) NOT NULL,
    codModelo INT(6) NOT NULL,
    codCategoria INT(2) NOT NULL,
    ano INT(4) NOT NULL,
    cpf BIGINT(11) ZEROFILL NOT NULL,
CONSTRAINT VEICULO_PK PRIMARY KEY (placa),
CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO (cpf),
CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (codModelo)
    REFERENCES MODELO (codModelo),
CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (codCategoria)
    REFERENCES CATEGORIA (codCategoria)
);

CREATE TABLE IF NOT EXISTS LOCALIZACAO (
    codLocal VARCHAR(20) NOT NULL,
    latitude DECIMAL(8,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    velocidadePermitida INT(3) NOT NULL,
CONSTRAINT LOCALIZACAO_PK PRIMARY KEY (codLocal)
);

CREATE TABLE IF NOT EXISTS AGENTE (
    matricula BIGINT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    dtContratacao DATE NOT NULL,
CONSTRAINT AGENTE_PK PRIMARY KEY (matricula)
);

CREATE TABLE IF NOT EXISTS TIPO_INFRACAO (
    codInfracao INT NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    valor DECIMAL(6,2) NOT NULL,
CONSTRAINT TIPO_INFRACAO_PK PRIMARY KEY (codInfracao)
);

CREATE TABLE IF NOT EXISTS INFRACAO(
    idInfracao BIGINT NOT NULL AUTO_INCREMENT,
    placa VARCHAR(7) NOT NULL,
    dataHora TIMESTAMP NOT NULL,
    codInfracao INT NOT NULL,
    codLocal VARCHAR(20) NOT NULL,
    velocidadeAferida INT(3),
    matricula BIGINT NOT NULL,
CONSTRAINT INFRACAO_PK PRIMARY KEY (idInfracao),
CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY (placa)
    REFERENCES VEICULO (placa),
CONSTRAINT INFRACAO_TIPO_INFRACAO_FK FOREIGN KEY (codInfracao)
    REFERENCES TIPO_INFRACAO (codInfracao),
CONSTRAINT INFRACAO_LOCALIZACAO_FK FOREIGN KEY (codLocal)
    REFERENCES LOCALIZACAO (codLocal),
CONSTRAINT INFRACAO_AGENTE_FK FOREIGN KEY (matricula)
    REFERENCES AGENTE (matricula)
) AUTO_INCREMENT=1;
