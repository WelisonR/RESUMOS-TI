-- ---------------------- << CONTROLE DE PLANTONISTAS (SSP-DF) ----------------------
-- 
--                               SCRIPT DE APAGAR (DDL)
--
-- Data de criacao .............: 12/05/2019
-- Autor .......................: Welison Lucas Almeida Regis
-- Base de dados ...............: MySQL
-- Base de dados(nome) .........: bdPlantao
--
-- Data Ultima Alteracao .......: 13/05/2019
-- => ELABORACAO DAS TABELAS
-- PROJETO => 01 base de dados
--         => 6 tabelas

USE bdPlantao;

DROP TABLE tem;
DROP TABLE trabalha;
DROP TABLE PLANTONISTA;
DROP TABLE SUPERVISOR;
DROP TABLE HABILIDADE;
DROP TABLE REGIAO;

