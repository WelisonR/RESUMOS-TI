-- ---------------------- << CONTROLE DE PLANTONISTAS (SSP-DF) ----------------------
-- 
--                               SCRIPT DE CRIACAO (DDL)
--
-- Data de criacao .............: 12/05/2019
-- Autor .......................: Welison Lucas Almeida Regis
-- Base de dados ...............: MySQL
-- Base de dados(nome) .........: bdPlantao
--
-- Data Ultima Alteracao .......: 13/05/2019
-- => ELABORACAO DAS TABELAS
-- PROJETO => 01 base de dados
--         => 6 tabelas

CREATE DATABASE IF NOT EXISTS bdPlantao;

USE bdPlantao;

CREATE TABLE REGIAO (
	nomeRegiao VARCHAR(50) NOT NULL,
	tamanho INT NOT NULL,
CONSTRAINT REGIAO_PK PRIMARY KEY (nomeRegiao)
) ENGINE = InnoDB;

CREATE TABLE HABILIDADE (
	idHabilidade INT NOT NULL AUTO_INCREMENT,
	habilidade VARCHAR(70) NOT NULL,
CONSTRAINT HABILIDADE_PK PRIMARY KEY (idHabilidade)
) ENGINE = InnoDB AUTO_INCREMENT=1;

CREATE TABLE SUPERVISOR (
	cpfSupervisor BIGINT(11) NOT NULL,
	matriculaFuncional INT NOT NULL UNIQUE,
	nome VARCHAR(50) NOT NULL,
	sexo ENUM('M', 'F') NOT NULL,
	dtNascimento DATE NOT NULL,
CONSTRAINT SUPERVISOR_PK PRIMARY KEY (cpfSupervisor)
) ENGINE = InnoDB;

CREATE TABLE PLANTONISTA (
	matriculaFuncional INT NOT NULL,
	cpfSupervisor BIGINT(11) NOT NULL,
	nome VARCHAR(50) NOT NULL,
	sexo ENUM('M', 'F') NOT NULL,
	dtNascimento DATE NOT NULL,
CONSTRAINT PLANTONISTA_PK PRIMARY KEY (matriculaFuncional),
CONSTRAINT PLANTONISTA_SUPERVISOR_FK FOREIGN KEY (cpfSupervisor)
REFERENCES SUPERVISOR (cpfSupervisor)
) ENGINE = InnoDB;

CREATE TABLE trabalha (
	data DATE NOT NULL,
	matriculaFuncional INT NOT NULL,
	nomeRegiao VARCHAR(50) NOT NULL,
CONSTRAINT trabalha_PK PRIMARY KEY (data, matriculaFuncional),
CONSTRAINT trabalha_PLANTONISTA_FK FOREIGN KEY (matriculaFuncional)
REFERENCES PLANTONISTA (matriculaFuncional),
CONSTRAINT trabalha_REGIAO_FK FOREIGN KEY (nomeRegiao)
REFERENCES REGIAO (nomeRegiao)
) ENGINE = InnoDB;

CREATE TABLE tem (
	matriculaFuncional INT NOT NULL,
	idHabilidade INT NOT NULL,
CONSTRAINT tem_PK PRIMARY KEY (matriculaFuncional, idHabilidade),
CONSTRAINT tem_PLANTONISTA_FK FOREIGN KEY (matriculaFuncional)
REFERENCES PLANTONISTA (matriculaFuncional),
CONSTRAINT tem_HABILIDADE_FK FOREIGN KEY (idHabilidade)
REFERENCES HABILIDADE(idHabilidade)
) ENGINE = InnoDB;
