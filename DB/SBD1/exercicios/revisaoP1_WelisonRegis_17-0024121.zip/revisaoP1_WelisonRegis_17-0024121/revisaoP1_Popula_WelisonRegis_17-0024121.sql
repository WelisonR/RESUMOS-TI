-- ---------------------- << CONTROLE DE PLANTONISTAS (SSP-DF) ----------------------
-- 
--                               SCRIPT DE POPULAR (DML)
--
-- Data de criacao .............: 12/05/2019
-- Autor .......................: Welison Lucas Almeida Regis
-- Base de dados ...............: MySQL
-- Base de dados(nome) .........: bdPlantao
--
-- Data Ultima Alteracao .......: 13/05/2019
-- => ELABORACAO DAS TABELAS
-- PROJETO => 01 base de dados
--         => 6 tabelas

USE bdPlantao;


--
-- POPULA REGIAO
--
INSERT INTO REGIAO VALUES (
	'Gama',
	277
);

INSERT INTO REGIAO VALUES (
	'Taguatinga',
	122
);

INSERT INTO REGIAO VALUES (
	'Sobradinho',
	288
);


--
-- POPULA HABILIDADE
--
INSERT INTO HABILIDADE VALUES (
	null,
	'Porte de arma'
);

INSERT INTO HABILIDADE VALUES (
	null,
	'Lutador de jiu-jitsu'
);

INSERT INTO HABILIDADE VALUES (
	null,
	'Primeiros socorros'
);


--
-- POPULA SUPERVISOR
--
INSERT INTO SUPERVISOR VALUES (
	02376937177,
	18001234,
	'João de Alcântara Salvador',
	'M',
	'1978-02-19'
);

INSERT INTO SUPERVISOR VALUES (
	77078912321,
	19004321,
	'Maria Cecília de Sousa Alves',
	'F',
	'1989-10-20'
);

INSERT INTO SUPERVISOR VALUES (
	11209312398,
	19001010,
	'Mario Salvador Domingo',
	'M',
	'1999-03-09'
);


--
-- POPULA PLANTONISTA
--
INSERT INTO PLANTONISTA VALUES (
	18011515,
	02376937177,
	'Cícero Chico Batista Lulia',
	'M',
	'1997-05-15'
);

INSERT INTO PLANTONISTA VALUES (
	19011717,
	77078912321,
	'Maria Luzia Goulart Gomes',
	'F',
	'1988-08-20'
);

INSERT INTO PLANTONISTA VALUES (
	19012020,
	11209312398,
	'João Domingues Temer',
	'M',
	'1989-06-07'
);


--
-- POPULA trabalha
-- 
INSERT INTO trabalha VALUES (
	'2019-06-12',
	18011515,
	'Gama'
);

INSERT INTO trabalha VALUES (
	'2019-07-05',
	19011717,
	'Taguatinga'
);

INSERT INTO trabalha VALUES (
	'2019-06-24',
	19012020,
	'Sobradinho'
);


--
-- POPULA tem
--
INSERT INTO tem VALUES (
	18011515,
	1
);

INSERT INTO tem VALUES (
	18011515,
	2
);

INSERT INTO tem VALUES (
	19011717,
	3
);

INSERT INTO tem VALUES (
	19012020,
	2
);
