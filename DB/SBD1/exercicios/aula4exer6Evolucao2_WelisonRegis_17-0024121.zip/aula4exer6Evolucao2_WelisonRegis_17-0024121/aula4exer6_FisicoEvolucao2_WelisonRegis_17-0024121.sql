-- --------------     << DETRAN - INFRAÇÕES >>     ------------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 25/04/2019
-- Autor(es) ..............: Welison Lucas Almeida Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: detran_infracoes
-- 
-- Data Ultima Alteracao ..: 25/04/2019
--   => Definição das tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 9 tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE detran_infracoes;

USE detran_infracoes;

CREATE TABLE PROPRIETARIO (
    cpf BIGINT(11) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    numero INT NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    uf CHAR(2) NOT NULL,
    cep INT(8) NOT NULL,
    sexo CHAR(1) NOT NULL,
    dtNascimento DATE NOT NULL,
    
    CONSTRAINT PROPRIETARIO_PK PRIMARY KEY (cpf)
);

CREATE TABLE telefone (
    cpf BIGINT(11) NOT NULL,
    telefone BIGINT(11) NOT NULL,
    
    CONSTRAINT telefone_PK PRIMARY KEY (cpf, telefone),
    CONSTRAINT telefone_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO (cpf)
);

CREATE TABLE MODELO (
    codModelo INT(6) NOT NULL,
    nomeModelo VARCHAR(50) NOT NULL,
    
    CONSTRAINT MODELO_PK PRIMARY KEY (codModelo)
);

CREATE TABLE CATEGORIA (
    codCategoria INT(2) NOT NULL,
    nomeCategoria VARCHAR(50),
    
    CONSTRAINT CATEGORIA_PK PRIMARY KEY (codCategoria)
);

CREATE TABLE VEICULO (
    placa CHAR(7) NOT NULL,
    numeroChassi CHAR(17) NOT NULL UNIQUE,
    cor VARCHAR(20) NOT NULL,
    codModelo INT(6) NOT NULL,
    codCategoria INT(2) NOT NULL,
    ano INT(4) NOT NULL,
    cpf BIGINT(11) NOT NULL,
    
    CONSTRAINT VEICULO_PK PRIMARY KEY (placa),
    CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (codModelo)
    REFERENCES MODELO (codModelo),
    CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (codCategoria)
    REFERENCES CATEGORIA (codCategoria),
    CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO (cpf)
);

CREATE TABLE TIPO_INFRACAO (
    codInfracao INT NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    valor DECIMAL(6, 2) NOT NULL,
    
    CONSTRAINT TIPO_INFRACAO_PK PRIMARY KEY (codInfracao)
);

CREATE TABLE AGENTE (
    matricula BIGINT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    dtContratacao DATE NOT NULL,
    
    CONSTRAINT AGENTE_PK PRIMARY KEY (matricula)
);

CREATE TABLE LOCALIDADE (
    codLocal VARCHAR(20) NOT NULL,
    latitude DECIMAL(8, 6) NOT NULL,
    longitude DECIMAL(9, 6) NOT NULL,
    velocidadePermitida INT(3) NOT NULL,
    
    CONSTRAINT LOCALIDADE_PK PRIMARY KEY (codLocal)
);

CREATE TABLE INFRACAO (
    idInfracao BIGINT NOT NULL,
    placa VARCHAR(7) NOT NULL UNIQUE,
    dataHora TIMESTAMP NOT NULL,
    codInfracao INT NOT NULL,
    codLocal VARCHAR(20) NOT NULL,
    velocidadeAferida INT(3) NOT NULL,
    matricula BIGINT NOT NULL,
    
    CONSTRAINT INFRACAO_PK PRIMARY KEY (idInfracao),
    CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY (placa)
    REFERENCES VEICULO (placa),
    CONSTRAINT INFRACAO_TIPO_INFRACAO FOREIGN KEY (codInfracao)
    REFERENCES TIPO_INFRACAO (codInfracao),
    CONSTRAINT INFRACAO_LOCALIDADE FOREIGN KEY (codLocal)
    REFERENCES LOCALIDADE (codLocal),
    CONSTRAINT INFRACAO_AGENTE FOREIGN KEY (matricula)
    REFERENCES AGENTE (matricula)
);
