-- ---------------     << RECEITUÁRIO - V4 >>     --------------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 22/04/2019
-- Autor(es) ..............: Welison Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer5Evolucao4
-- 
-- Data Ultima Alteracao ..: 02/05/2019
--   => Criacao de nova tabela
--   => Edição de atributos do crm e algumas constraints
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer5Evolucao4;

USE aula4exer5Evolucao4;



CREATE TABLE IF NOT EXISTS MEDICO (
   	crm VARCHAR(8) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    
    CONSTRAINT MEDICO_PK PRIMARY KEY (crm)
);

CREATE TABLE IF NOT EXISTS ESPECIALIDADE (
	codEspecialista INT NOT NULL,
    nomeEspecialista VARCHAR(30) NOT NULL,
    
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (codEspecialista)
);

CREATE TABLE IF NOT EXISTS possui (
	crm VARCHAR(8) NOT NULL,
    codEspecialista INT NOT NULL,
    
    CONSTRAINT possui_PK PRIMARY KEY (codEspecialista, crm),
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY (crm)
    REFERENCES MEDICO (crm),
    CONSTRAINT possui_ESPECIALIADADE_FK FOREIGN KEY (codEspecialista)
    REFERENCES ESPECIALIDADE (codEspecialista)
);

CREATE TABLE IF NOT EXISTS PACIENTE (
	cpf VARCHAR(11) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    sexo VARCHAR(1) NOT NULL,
    idade INT(3) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    cidade VARCHAR(30) NOT NULL,
    bairro VARCHAR(30) NOT NULL,
    logradouro VARCHAR(30) NOT NULL,
    cep VARCHAR(8) NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    numero INT(5) NOT NULL,
	
	CONSTRAINT PACIENTE_PK PRIMARY KEY (cpf)
);

CREATE TABLE IF NOT EXISTS telefone (
	telefone VARCHAR(11),
    cpf VARCHAR(11) NOT NULL,
    
    CONSTRAINT telefone_PK PRIMARY KEY (telefone, cpf),
    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (cpf)
    REFERENCES PACIENTE (cpf)
);

CREATE TABLE IF NOT EXISTS CONSULTA (
	cpf VARCHAR(11) NOT NULL,
    crm VARCHAR(8) NOT NULL,
    dataHora TIMESTAMP NOT NULL,
    
    CONSTRAINT CONSULTA_PK PRIMARY KEY (cpf, crm, dataHora),
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (cpf)
    REFERENCES PACIENTE (cpf),
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (crm)
    REFERENCES MEDICO (crm)
);

CREATE TABLE IF NOT EXISTS RECEITA (
	idReceita INT AUTO_INCREMENT NOT NULL,
    dataHora TIMESTAMP NOT NULL,
    crm VARCHAR(8) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    posologia VARCHAR(250) NOT NULL,
    
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    CONSTRAINT RECEITA_CONSULTA_FK FOREIGN KEY (cpf, crm, dataHora)
    REFERENCES CONSULTA (cpf, crm, dataHora)
);

CREATE TABLE IF NOT EXISTS MEDICAMENTO (
	codMedicamento INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    descricao VARCHAR(50) NOT NULL,
    
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (codMedicamento)
);

CREATE TABLE IF NOT EXISTS contem (
	idReceita INT NOT NULL,
    codMedicamento INT NOT NULL,
    
    CONSTRAINT contem_PK PRIMARY KEY (idReceita, codMedicamento),
    CONSTRAINT contem_RECEITA_FK FOREIGN KEY (idReceita)
    REFERENCES RECEITA (idReceita),
    CONSTRAINT contem_MEDICAMENTO_FK FOREIGN KEY (codMedicamento)
    REFERENCES MEDICAMENTO (codMedicamento)
);
