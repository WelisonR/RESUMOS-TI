-- -----------     << RECEITUÁRIO - V4 >>     -------------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 02/05/2019
-- Autor(es) ..............: Welison Regis
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer5Evolucao4
-- 
-- Data Ultima Alteracao ..: 02/05/2019
--   => Criação do script para apagar os dados do banco
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------


USE aula4exer5Evolucao4;

DROP TABLE contem;
DROP TABLE MEDICAMENTO;
DROP TABLE RECEITA;
DROP TABLE CONSULTA;
DROP TABLE telefone;
DROP TABLE PACIENTE;
DROP TABLE possui;
DROP TABLE ESPECIALIDADE;
DROP TABLE MEDICO;