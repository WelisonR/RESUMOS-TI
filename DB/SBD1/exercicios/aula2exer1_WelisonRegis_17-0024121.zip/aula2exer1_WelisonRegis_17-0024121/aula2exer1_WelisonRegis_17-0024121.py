import os
import bisect

LENGTH_CPF = 11
LENGTH_RENAVAM = 11 


class Car:
    def __init__(self, ID_owner, renavam):
        self.ID_owner = int(ID_owner)
        self.renavam = renavam

    def __lt__(self, other):
        return self.renavam < other.renavam


class Person:
    PERSON_ID = 1

    def __init__(self, first_name, last_name, CPF):
        self.ID = int(Person.PERSON_ID)
        self.first_name = first_name
        self.last_name = last_name
        self.CPF = CPF

        Person.PERSON_ID += 1
    
    def __lt__(self, other):
        return self.ID < other.ID


def clear_terminal():
    os.system('cls' if os.name == 'nt' else 'clear')

def load_persons():
    persons = []

    with open('./data/persons.txt', 'r') as file:
        # ignore head line
        file.readline()
        
        for line in file:
            data = line.split()

            first_name = data[1].strip()
            last_name = data[2].strip()
            CPF = data[3].strip()

            person = Person(first_name, last_name, CPF)
            persons.append(person)

    return persons

def load_cars():
    cars = []

    with open('./data/cars.txt', 'r') as file:
        # ignore head line
        file.readline()
        
        for line in file:
            data = line.split()

            ID_owner = int(data[0].strip())
            renavam = data[1].strip()

            car = Car(ID_owner, renavam)
            bisect.insort(cars, car)
    
    return cars

def save_persons(persons):
    file = open('./data/persons.txt','w')
    file.write('{:<10}{:<20}{:<20}{:<15}\n'.format(
        'ID', 'PRIMEIRO_NOME', 'ULTIMO_NOME', 'CPF'))

    for person in persons:
        file.write('{:<10}{:<20}{:<20}{:<15}\n'.format(
            person.ID, person.first_name, person.last_name, person.CPF))

    file.close()

def save_cars(cars):
    file = open('./data/cars.txt', 'w')
    file.write('{:<20}{:<20}\n'.format('ID_PROPRIETARIO', 'RENAVAM'))

    for car in cars:
        file.write('{:<20}{:<20}\n'.format(car.ID_owner, car.renavam))
    
    file.close()

def show_car():
    print(r"""
       -           __
 --          ~( @\   \ 
---   _________]_[__/_>________
     /  ____ \ <>     |  ____  \ 
    =\_/ __ \_\_______|_/ __ \__D
________(__)_____________(__)____
    """)

def enter_to_continue():
    print('\nPressione ENTER para voltar ao menu!')
    input('>>> : ')

def verify_data_integrity(cars, CPF, first_name, last_name, renavam):
    error = False

    print('\n\n')
    if len(CPF) != LENGTH_CPF or not CPF.isdigit():
        error = True
        print('O CPF deve conter 11 DÍGITOS!')
    
    space = " "
    if space in first_name or space in last_name:
        error = True
        print('Digite APENAS UM NOME, sem espaços!')
    elif len(first_name) == 0 or len(last_name) == 0:
        error = True
        print('O nome não pode ser vazio!')
    elif not first_name.isalpha() or not last_name.isalpha():
        print('O nome não pode conter números!')

    if len(renavam) != LENGTH_RENAVAM or not renavam.isdigit():
        error = True
        print('O RENAVAM deve conter 11 DÍGITOS!')
    
    error2 = verify_renavam_existence(cars, renavam)
    if error2 == True:
        error = True
        print('O RENAVAM já existe em nosso banco de dados!')

    return error

def verify_person_existence(persons, CPF):
    for person in persons:
        if person.CPF == CPF:
            return person.ID
    else:
        return -1

def verify_renavam_existence(cars, renavam):
    error = False
    for car in cars:
        if car.renavam == renavam:
            error = True
            break
    
    return error

def show_all_cars(persons, cars):
    clear_terminal()
    print(85*'*')
    print('*{:<20} {:<20} {:<20} {:<20}*'.format(
        'PRIMEIRO NOME', 'ÚLTIMO NOME', 'CPF', 'RENAVAM'))
    print('*{}*'.format(83*'-'))

    for car in cars:
        owner_index = car.ID_owner-1
        first_name = persons[owner_index].first_name
        last_name = persons[owner_index].last_name
        CPF = persons[owner_index].CPF
        CPF = CPF[0:3] + '.' + CPF[3:6] + '.' + CPF[6:9] + '-' + CPF[9:11]
        
        renavam = car.renavam

        print('*{:<20} {:<20} {:<20} {:<20}*'.format(
            first_name, last_name, CPF, renavam))

    print(85*'*')
    print('\n!! DADOS ORDENADOS PELO RENAVAM !!\n')

    enter_to_continue()

def insert_new_car(persons, cars):
    clear_terminal()
    show_car()

    CPF = input('Informe o seu CPF (apenas os 11 dígitos): ')
    first_name = input('Informe o seu PRIMEIRO NOME: ').capitalize()
    last_name = input('Informe o seu ÚLTIMO NOME: ').capitalize()
    renavam = input('Informe o RENAVAM do carro (apenas os 11 dígitos): ')

    error = verify_data_integrity(cars, CPF, first_name, last_name, renavam)

    if error:
        enter_to_continue()
    else:
        person_ID = verify_person_existence(persons, CPF)
        if person_ID == -1:
            person = Person(first_name, last_name, CPF)
            car = Car(person.ID, renavam)

            # bisect insere com baixo custo computacional em um CONJUNTO ORDENADO de dados
            bisect.insort(cars, car)
            persons.append(person)
        else:
            car = Car(person_ID, renavam)

            # bisect insere com baixo custo computacional em um CONJUNTO ORDENADO de dados
            bisect.insort(cars, car)
        
        save_persons(persons)
        save_cars(cars)
    
    return persons, cars

def search_person_car(persons, cars):
    clear_terminal()
    show_search_menu()

    opt = input('\n>>> : ')
    
    renavams = []
    if opt == '1':
        print('\nDigite o RENAVAM (somente OS 11 números): ')
        renavam = input('>>> : ')

        if not renavam.isdigit() or len(renavam) != LENGTH_RENAVAM:
            print('\nRENAVAM INVÁLIDO!')
            enter_to_continue()

            return

        id_owner = -1
        for car in cars:
            if car.renavam == renavam:
                id_owner = car.ID_owner
                break
        
        if id_owner == -1:
            print('\nRENAVAM não encontrado no banco de dados!')
            enter_to_continue()

            return
        else:
            renavams.append(renavam)
            show_owner_cars(persons, cars, id_owner, renavams) 
    elif opt == '2':
        print('\nDigite o CPF (somente os 11 números): ')
        CPF = input('>>> : ')

        if not CPF.isdigit() or len(CPF) != LENGTH_CPF:
            print('\nCPF INVÁLIDO!')
            enter_to_continue()

            return

        person_index = verify_person_existence(persons, CPF)
        if person_index == -1:
            print('\nCPF não encontrado no banco de dados!')

            enter_to_continue()
        else:
            for car in cars:
                if car.ID_owner == person_index:
                    renavams.append(car.renavam)
                    
            show_owner_cars(persons, cars, person_index, renavams)
    elif opt == '0':
        return
    else:
        invalid_menu_opt()

def show_owner_cars(persons, cars, ID, renavams):
    if len(renavams) == 0:
        print('\nNão há nenhum carro associado!')
        enter_to_continue()

        return
    
    clear_terminal()
    print(85*'*')
    print('*{:<20} {:<20} {:<20} {:<20}*'.format(
        'PRIMEIRO NOME', 'ÚLTIMO NOME', 'CPF', 'RENAVAM'))
    print('*{}*'.format(83*'-'))

    first_name = persons[ID-1].first_name
    last_name = persons[ID-1].last_name
    CPF = persons[ID-1].CPF
    CPF = CPF[0:3] + '.' + CPF[3:6] + '.' + CPF[6:9] + '-' + CPF[9:11]

    for renavam in renavams:
        print('*{:<20} {:<20} {:<20} {:<20}*'.format(
            first_name, last_name, CPF, renavam))
    
    print(85*'*')

    enter_to_continue()

    return

def show_search_menu():
    print('_________________________________________________________')
    print('|                  PROCURAR VEÍCULO(S)                  |')
    print('|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|')
    print('|Por favor, escolha uma opção:                          |')
    print('|                                                       |')
    print('|1- Procurar proprietário de carro por RENAVAM          |')
    print('|2- Procurar carros de proprietário por CPF             |')
    print('|0- Voltar ao menu principal!                           |')
    print('|_______________________________________________________|')
    

def show_main_menu():
    print('_________________________________________________________')
    print('|                REGISTRADOR DE VEÍCULOS                |')
    print('|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|')
    print('|Por favor, escolha uma opção:                          |')
    print('|                                                       |')
    print('|1- Listar todos os veículos e os seus respectivos donos|')
    print('|2- Procurar carros de proprietário por CPF ou RENAVAM  |')
    print('|3- Incluir novo veículo à lista de carros              |')
    print('|0- Sair da aplicação!                                  |')
    print('|_______________________________________________________|')

def invalid_menu_opt():
    clear_terminal()
    print('\nPor favor, digite uma opção válida!')
    print('\n\nPressione ENTER para voltar ao menu!')
    input('>>> : ')
    clear_terminal()

def main():
    persons = load_persons()
    cars = load_cars()
    while(True):
        clear_terminal()
        show_main_menu()
        opt = input('\n>>> : ')
        if opt == '0':
            break
        elif opt == '1':
            show_all_cars(persons, cars)
        elif opt == '2':
            search_person_car(persons, cars)
        elif opt == '3':
            # insert and save new car to files
            persons, cars = insert_new_car(persons, cars)
        else:
            invalid_menu_opt()

if __name__ == "__main__":
    main()

